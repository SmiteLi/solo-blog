title: a example of yaml file
date: '2019-12-11 11:26:18'
updated: '2019-12-11 11:26:18'
tags: [yaml]
permalink: /articles/2019/12/11/1576034777987.html
---
```yml
---
# An employee record
name: Martin D'vloper
job: Developer
skill: Elite
employed: True
foods:
    - Apple
    - Orange
    - Strawberry
    - Mango
languages:
    perl: Elite
    python: Elite
    pascal: Lame
education: |
    4 GCSEs
    3 A-Levels
    BSc in the Internet of Things
```
