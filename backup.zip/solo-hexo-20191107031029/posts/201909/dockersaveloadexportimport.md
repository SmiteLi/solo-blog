title: docker save/load/export/import
date: '2019-09-16 17:46:04'
updated: '2019-10-11 14:34:34'
tags: [docker]
permalink: /articles/2019/09/16/1568627164223.html
---

## 一、

```
导出导入镜像：
$ docker save alpine | gzip > alpine-latest.tar.gz
$ docker load -i alpine-latest.tar.gz
docker save <镜像名> | bzip2 | pv | ssh <用户名>@<主机名> 'cat | docker load'

docker save -o redis4.0-docker.tar redis:4
docker load --input 文件
docker load -i 文件

导出导入容器：
导出容器
如果要导出本地某个容器，可以使用 docker export 命令。
$ docker container ls -a
$ docker export 7691a814370e > ubuntu.tar

导入容器快照
可以使用 docker import 从容器快照文件中再导入为镜像，例如
$ cat ubuntu.tar | docker import - test/ubuntu:v1.0
$ docker image ls

```

## 二、导出并解压
```
docker save mysql:8 | xz > mysql.tar.xz

docker save alpine | gzip > alpine-latest.tar.gz
docker load -i alpine-latest.tar.gz
```
