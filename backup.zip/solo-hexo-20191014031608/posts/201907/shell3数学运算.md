title: shell-3-数学运算
date: '2019-07-20 17:33:04'
updated: '2019-07-20 17:33:04'
tags: [shell, Linux]
permalink: /articles/2019/07/20/1563615184000.html
---
shell脚本如下：vim math.sh
```
#!/bin/bash

number1=10
number2=20
number3=30

let result1=number1+number2
echo $result1

let number1++
let number3-=5

result2=$[ number1 + number3 ]
echo $result2

result3=$[ $number2 + 5 ]
echo $result3

result4=$(( number3 + 25 ))
echo $result4

result5=`expr 3 + 4`
echo $result5

result6=$(expr $number1 + 8)
echo $result6
```
执行结果如下：
```
smite@smite:~$ bash math.sh 
30
36
25
50
7
19

```

利用bc命令进行计算：vim bc.sh
```
<pre>#!/bin/bash

echo &quot;4 * 0.56&quot; | bc

number1=54
result=`echo &quot;$number1 * 1.15&quot; | bc`
echo $result

# 设置小数精度
echo &quot;scale=3;22/7&quot; | bc

# 进制转换
number2=100
echo &quot;obase=2;$number2&quot; | bc
number3=1100100
echo &quot;obase=10;ibase=2;$number3&quot; | bc

echo &quot;sqrt(100)&quot; | bc
echo &quot;10^10&quot; | bc

```
执行结果如下：
```
smite@smite:~$ bash bc.sh 
2.24
62.10
3.142
1100100
100
10

```
























