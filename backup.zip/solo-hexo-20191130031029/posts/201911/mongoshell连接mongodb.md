title: mongo shell连接mongodb
date: '2019-11-29 16:25:37'
updated: '2019-11-29 16:25:37'
tags: [mongo]
permalink: /articles/2019/11/29/1575015937344.html
---
## 参考：[链接](https://docs.mongodb.com/manual/mongo/)

### 1. Start the `mongo` Shell and Connect to MongoDB
```
mongo "mongodb://alice:Admin!2#@mongodb0.examples.com:28015/?authSource=admin"

mongo --username alice --password --authenticationDatabase admin --host mongodb0.examples.com --port 28015
```

### 2. Connect to a MongoDB Replica Set
```
mongo "mongodb://mongodb0.example.com.local:27017,mongodb1.example.com.local:27017,mongodb2.example.com.local:27017/?replicaSet=replA"
mongo --host replA/mongodb0.example.com.local:27017,mongodb1.example.com.local:27017,mongodb2.example.com.local:27017
```
If using the [DNS Seedlist Connection Format](https://docs.mongodb.com/manual/reference/connection-string/#connections-dns-seedlist), you can specify the connection string:

```
mongo "mongodb+srv://server.example.com/"
```
Use of the `+srv` connection string modifier automatically sets the ssl option to true for the connection.

### 3. TLS/SSL Connection
```
mongo "mongodb://mongodb0.example.com.local:27017,mongodb1.example.com.local:27017,mongodb2.example.com.local:27017/?replicaSet=replA&ssl=true"

mongo --ssl --host replA/mongodb0.example.com.local:27017,mongodb1.example.com.local:27017,mongodb2.example.com.local:27017
```

## Working with the `mongo` Shell

```
db
use <database>
use myNewDatabase
db.myCollection.insertOne( { x: 1 } );
db.getCollection("3 test").find()
db.getCollection("3-test").find()
db.getCollection("stats").find()
```

### Format Printed Results
```
db.myCollection.find().pretty()
```

## `.mongorc.js` File
When starting, [`mongo`](https://docs.mongodb.com/manual/reference/program/mongo/#bin.mongo "bin.mongo") checks the user’s [`HOME`](https://docs.mongodb.com/manual/reference/program/mongo/#envvar-HOME) directory for a JavaScript file named [.mongorc.js](https://docs.mongodb.com/manual/reference/program/mongo/#mongo-mongorc-file)
