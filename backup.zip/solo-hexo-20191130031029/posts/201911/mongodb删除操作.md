title: mongodb删除操作
date: '2019-11-28 16:02:54'
updated: '2019-11-28 16:04:31'
tags: [mongo]
permalink: /articles/2019/11/28/1574928174643.html
---
```
aaa_ca_corp_info_gk
db.auth("admin","aaa@169.com&")
db.createCollection("aaa_person_info_gk")


db.aaa_person_info_gk.find().pretty()
db.aaa_person_info_gk.remove({})

db.aaa_ca_corp_info_gk.find().pretty()
db.aaa_ca_corp_info_gk.remove( { } )

db.createCollection( aaa_ca_corp_info_gk,
   {
     capped: <boolean>,
     autoIndexId: <boolean>,
     size: <number>,
     max: <number>,
     storageEngine: <document>,
     validator: <document>,
     validationLevel: <string>,
     validationAction: <string>,
     indexOptionDefaults: <document>,
     viewOn: <string>,              // Added in MongoDB 3.4
     pipeline: <pipeline>,          // Added in MongoDB 3.4
     collation: <document>,         // Added in MongoDB 3.4
     writeConcern: <document>
   }
)
```
