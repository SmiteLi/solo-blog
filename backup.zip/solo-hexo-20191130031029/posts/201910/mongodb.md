title: mongodb
date: '2019-10-29 17:43:58'
updated: '2019-10-29 17:43:58'
tags: [mongo]
permalink: /articles/2019/10/29/1572342238854.html
---
docker run --restart=always --name mongo -v {{work_dir}}:/data/mongo --network host -d mongo mongod {{mongo_replica_set_parameter}} --port {{mongo_port}} --bind_ip 0.0.0.0 --dbpath /data/mongo --keyFile /data/mongo/mongo_keyfile --directoryperdb --auth
