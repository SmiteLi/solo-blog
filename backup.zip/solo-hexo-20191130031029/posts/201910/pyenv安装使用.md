title: pyenv安装使用
date: '2019-10-18 15:00:44'
updated: '2019-10-18 15:00:44'
tags: [python]
permalink: /articles/2019/10/18/1571382043989.html
---
#

## 1. install

https://github.com/pyenv/pyenv-installer

## 2. pyenv
