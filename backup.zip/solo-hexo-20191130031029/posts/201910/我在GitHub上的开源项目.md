title: 我在 GitHub 上的开源项目
date: '2019-10-06 03:00:29'
updated: '2019-10-06 03:00:29'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [linux-basic-command](https://github.com/SmiteLi/linux-basic-command) <kbd title="主要编程语言">Shell</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/SmiteLi/linux-basic-command/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/SmiteLi/linux-basic-command/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/SmiteLi/linux-basic-command/network/members "分叉数")</span>

the usage of linux basic command



---

### 2. [solo-blog](https://github.com/SmiteLi/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/SmiteLi/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/SmiteLi/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/SmiteLi/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://smite.site`](https://smite.site "项目主页")</span>

IT技术札记 - Smite 的个人博客 - 记录人生点滴



---

### 3. [gonote](https://github.com/SmiteLi/gonote) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/SmiteLi/gonote/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/SmiteLi/gonote/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/SmiteLi/gonote/network/members "分叉数")</span>

the note of learn go



---

### 4. [python-note](https://github.com/SmiteLi/python-note) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/SmiteLi/python-note/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/SmiteLi/python-note/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/SmiteLi/python-note/network/members "分叉数")</span>

the note of learning python

