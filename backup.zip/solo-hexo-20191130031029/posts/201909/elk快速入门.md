title: elk快速入门
date: '2019-09-04 14:29:42'
updated: '2019-09-04 14:29:42'
tags: [elk]
permalink: /articles/2019/09/04/1567578582388.html
---
下面为官方elk快速入门连接：
https://www.elastic.co/cn/start
