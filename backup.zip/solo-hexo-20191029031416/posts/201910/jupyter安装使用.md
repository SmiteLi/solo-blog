title: jupyter安装使用
date: '2019-10-18 14:32:10'
updated: '2019-10-18 14:32:10'
tags: [python]
permalink: /articles/2019/10/18/1571380330907.html
---
# jupyter安装使用

## 1. install jupyter

refer：https://jupyter.org/install

## 2. use jupyter

refer：https://jupyter.readthedocs.io/en/latest/running.html#running
