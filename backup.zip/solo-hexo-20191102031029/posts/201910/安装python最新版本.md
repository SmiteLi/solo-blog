title: 安装python最新版本
date: '2019-10-18 14:00:03'
updated: '2019-10-18 14:00:03'
tags: [python]
permalink: /articles/2019/10/18/1571378403620.html
---
  ``` bash
  wget https://www.python.org/ftp/python/2.7.15/Python-2.7.15.tgz
  tar zxf Python-2.7.15.tgz
  cd Python-2.7.15
  ./configure --prefix=/data/solution/python2.7
  make -j `cat /proc/cpuinfo| grep "processor"| wc -l` && make install
  ```
