title: 安装ansible
date: '2019-09-02 14:36:57'
updated: '2019-09-02 14:36:57'
tags: [Linux, ansible]
permalink: /articles/2019/09/02/1567406217520.html
---
## 一、基础知识/将安装什么

默认情况下，Ansible通过SSH协议管理计算机。

一旦安装了Ansible，它就不会添加数据库，并且没有守护进程可以启动或继续运行。您只需将它安装在一台机器上（很容易就是笔记本电脑），它就可以从该中心点管理整个远程机器。当Ansible管理远程计算机时，它不会在其上安装或运行软件，因此在迁移到新版本时如何升级Ansible并不存在真正的问题。

## 二、选择什么版本？

因为它可以从源代码轻松运行，并且不需要在远程计算机上安装任何软件，所以许多用户实际上都会跟踪开发版本。

  

Ansible的发布周期通常约为四个月。由于这个短暂的发布周期，通常会在下一个版本中修复小错误，而不是在稳定分支上维护反向移植。在需要时，主要错误仍然会有维护版本，尽管这些很少发生。

  

如果您希望运行最新发布的Ansible版本，并且您运行的是Red Hat Enterprise Linux（TM），CentOS，Fedora，Debian或Ubuntu，我们建议您使用OS软件包管理器。

  

对于其他安装选项，我们建议安装via pip，这是Python包管理器。

  

如果您希望跟踪要使用的开发版本并测试最新功能，我们将共享有关从源代码运行的信息。没有必要安装程序从源代码运行。

  

## 三、（主控）控制节点要求

目前Ansible可以从安装了Python 2（2.7版）或Python 3（3.5及更高版本）的任何机器上运行。控制节点不支持Windows。

  

这包括Red Hat，Debian，CentOS，macOS，任何BSD等等。

  

**注意：**

>默认情况下，macOS是针对少量文件句柄配置的，因此如果要使用15个或更多个分支，则需要使用提升ulimit 。此命令还可以修复任何“打开太多文件”错误:

`sudo launchctl limit maxfiles unlimited`

  

警告

  

请注意，某些模块和插件还有其他要求。对于模块，需要在“目标”机器上满足这些模块的依赖条件，并且应该在模块特定的文档中列出。

  

## 四、受管节点要求

在受管节点上，您需要一种通信方式，通常是ssh。默认情况下，这使用sftp。如果没有，你可以切换到scp 在 ansible.cfg文件。您还需要Python 2（2.6或更高版本）或Python 3（3.5或更高版本）。

  

**注意**

  

> 如果在远程节点上启用了SELinux，则在使用Ansible中的任何复制/文件/模板相关功能之前，还需要在其上安装libselinux-python。您可以使用Ansible中的yum模块或dnf模块在没有它的远程系统上安装此软件包。

  

默认情况下，Ansible使用位于其中的python解释器/usr/bin/python来运行其模块。但是，某些Linux发行版/usr/bin/python3默认情况下可能只安装了Python 3解释器 。在这些系统上，您可能会看到如下错误：

  

`"module_stdout": "/bin/sh: /usr/bin/python: No such file or directory\r\n"`

您可以将ansible_python_interpreter清单变量（请参阅 使用清单）设置为指向解释器，也可以为要使用的模块安装Python 2解释器。如果Python 2解释器未安装到/ usr / bin / python，您仍需要设置ansible_python_interpreter。

  

Ansible的“raw”模块（用于以快速和脏的方式执行命令）和脚本模块甚至不需要安装Python。从技术上讲，您可以使用Ansible使用原始模块安装兼容版本的Python ，然后允许您使用其他所有内容。例如，如果您需要将Python 2引导到基于RHEL的系统上，则可以通过它安装它

  

`$ ansible myhost --become -m raw -a "yum install -y python2"`

### 4.1 安装控制节点

* 通过DNF或Yum发布最新版本

在Fedora上：

  

`$ sudo dnf install ansible`

在RHEL和CentOS上：

  

`$ sudo yum install ansible`

RHEL 7和RHEL 8的RPM可从Ansible Engine存储库获得。

  

要为RHEL 8启用Ansible Engine存储库，请运行以下命令：

  

`$ sudo subscription-manager repos --enable ansible-2.8-for-rhel-8-x86_64-rpms`

要为RHEL 7启用Ansible Engine存储库，请运行以下命令：

  

`$ sudo subscription-manager repos --enable rhel-7-server-ansible-2.8-rpms`

当前支持的RHEL，CentOS和Fedora版本的RPM可以从EPEL以及releases.ansible.com获得。

  

Ansible 2.4及更高版本可以管理包含Python 2.6或更高版本的早期操作系统。

  

您也可以自己构建RPM。从结帐或tarball的根目录，使用该命令构建可以分发和安装的RPM。make rpm

  

```
$ git clone https://github.com/ansible/ansible.git

$ cd ./ansible

$ make rpm

$ sudo rpm -Uvh ./rpm-build/ansible-*.noarch.rpm
```

* 通过Apt（Ubuntu）的最新版本

这里有一个PPA版本的Ubuntu版本。

  

要在您的计算机上配置PPA并安装ansible，请运行以下命令：

```
  
$ sudo apt update

$ sudo apt install software-properties-common

$ sudo apt-add-repository --yes --update ppa:ansible/ansible

$ sudo apt install ansible
```

**注意**

> 在较旧的Ubuntu发行版中，“software-properties-common”被称为“python-software-properties”。您可能希望使用apt-get而不是apt旧版本。另外，请注意，只有较新的发行版（即18.04,18.10等）具有-u或--update标记，因此请相应地调整脚本。

  

Debian / Ubuntu包也可以从源签出构建，运行：

  

`$ make deb`

您可能还希望从源代码运行以获取最新版本，如下所述。

  

通过Apt（Debian）发布的最新版本

Debian用户可以使用与Ubuntu PPA相同的源。

  

将以下行添加到/etc/apt/sources.list：

  

`deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main`

然后运行以下命令：

  

```
$ sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys 93C4A3FD7BB9C367

$ sudo apt update

$ sudo apt install ansible
```

**注意**

> 此方法已通过Debian Jessie和Stretch中的Trusty源验证，但在早期版本中可能不受支持。您可能希望使用apt-get而不是apt旧版本。

  

* 最新版本通过Portage（Gentoo）

`$ emerge -av app-admin/ansible`

要安装最新版本，您可能需要在出现之前取消屏蔽ansible软件包：

  
`
$ echo 'app-admin/ansible' >> /etc/portage/package.accept_keywords`

通过pkg发布的最新版本（FreeBSD）

虽然Ansible适用于Python 2和3版本，但FreeBSD对每个Python版本都有不同的包。所以安装你可以使用：

  

`$ sudo pkg install py27-ansible`

要么：

  

`$ sudo pkg install py36-ansible`

您可能还希望从端口安装，运行：

  

`$ sudo make -C /usr/ports/sysutils/ansible install`

您也可以选择特定版本，即 **ansible25**。

  

旧版本的FreeBSD使用类似的东西（替换你选择的包管理器）：

  

`$ sudo pkg install ansible`

关于macOS的最新发布

在Mac上安装Ansible的首选方法是通过pip。

  

可以通过Pip部分在最新版本中找到说明。如果您运行的是macOS版本10.12或更早版本，那么您应该升级到最新版本pip以安全地连接到Python Package Index。


* 通过Pip发布的最新版本

Ansible可以通过pipPython包管理器安装。如果pip您的Python系统尚未提供，请运行以下命令进行安装：

  

```
$ curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py

$ python get-pip.py --user
```

然后安装Ansible [1]：

  

`$ pip install --user ansible`


或者，如果您正在寻找最新的开发版本：

  

`$ pip install --user git+https://github.com/ansible/ansible.git@devel`

如果您在macOS Mavericks（10.9）上安装，您可能会遇到来自编译器的一些噪音。解决方法是执行以下操作：

  

`$ CFLAGS=-Qunused-arguments CPPFLAGS=-Qunused-arguments pip install --user ansible`

要使用所需的paramiko连接插件或模块paramiko，请安装所需的模块[2]：

  

`$ pip install --user paramiko`

Ansble也可以安装在新的或现有的内部virtualenv：

```
$ python -m virtualenv ansible # Create a virtualenv if one does not already exist

$ source ansible/bin/activate # Activate the virtual environment

$ pip install ansible
```

如果要全局安装Ansible，请运行以下命令：

 
```
$ sudo python get-pip.py

$ sudo pip install ansible
```

注意

 
运行pip  with sudo将对系统进行全局更改。由于pip不与系统包管理器协调，因此它可能会对您的系统进行更改，使其在非运行状态下保持不一致。对于macOS尤其如此。--user建议使用安装，除非您完全了解修改系统上的全局文件的含义。



* 标记的tar包发布

包装Ansible或想自己建立一个本地包，但不想做一个git checkout？发布的Tarball可在Ansible下载页面上找到。



从源码运行

Ansible很容易从源头运行。您不需要root使用它的权限，也没有实际安装的软件。无需守护程序或数据库设置。因此，我们社区中的许多用户始终使用Ansible的开发版本，因此他们可以在实现时利用新功能并轻松地为项目做出贡献。因为没有什么可以安装，所以开发版本比大多数开源项目容易得多。

  

**注意**

  

> 如果您想使用Ansible Tower作为控制节点，请不要使用Ansible的源安装。请使用OS包管理器（如apt或yum）或pip安装稳定版本。

  

要从源安装，请克隆Ansible git存储库：

  
```

$ git clone https://github.com/ansible/ansible.git

$ cd ./ansible
```

一旦git克隆了Ansible存储库，请设置Ansible环境：

  

使用Bash：

  
`
$ source ./hacking/env-setup`

使用fish：

  
`$ source ./hacking/env-setup.fish`

如果要抑制虚假警告/错误，请使用：

  

`$ source ./hacking/env-setup -q`

如果您pip的Python版本中没有安装，请安装它：

  

```
$ curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py

$ python get-pip.py --user
```

Ansible还使用了以下需要安装的Python模块[1]：

  

`$ pip install --user -r ./requirements.txt`

要更新ansible checkouts，请使用pull-with-rebase，以便重播任何本地更改。

  

```
$ git pull --rebase
~~~~
$ git pull --rebase #same as above

$ git submodule update --init --recursive
```

运行env-setup脚本后，您将从checkout运行，默认库存文件将是`/etc/ansible/hosts`。您可以选择指定清单文件（请参阅使用清单），但不包括/etc/ansible/hosts：

```
$ echo "127.0.0.1" > ~/ansible_hosts

$ export ANSIBLE_INVENTORY=~/ansible_hosts
```


  

现在让我们用ping命令测试一下：

`$ ansible all -m ping --ask-pass`



 
