title: mongodb导入csv文件
date: '2019-10-06 21:00:31'
updated: '2019-10-06 23:07:58'
tags: [mongo]
permalink: /articles/2019/10/06/1570366831069.html
---
参考链接：
https://blog.csdn.net/u012318074/article/details/77713228
https://docs.mongodb.com/manual/reference/program/mongoimport/

```bash
下面命令会自动创建数据库和表：
mongoimport --db foo --collection user_metainfo --type csv --headerline --ignoreBlanks --file /root/yss_user_data_100.csv

根据以上参考命令，得到：
mongoimport --host 127.0.0.1 --port 18081 --username admin --password "foo@169.com&" --authenticationDatabase admin \
  --db foo --collection account_metainfo --type csv --headerline --ignoreBlanks --file /data/solution/mongodb3.6/yss_import_userinfo_data/yss_user_data.csv
  
--authenticationDatabase=<dbname>
Specifies the authentication database where the specified --username has been created

检查命令：  
db.auth("admin","foo@169.com&")
use foo
db.account_metainfo.find()
db.account_metainfo.count()
 


参考操作命令：
db.help();                 #显示数据库操作命令，里面有很多的命令 
db.foo.help();             #显示集合操作命令，同样有很多的命令，foo指的是当前数据库下，一个叫foo的集合，并非真正意义上的命令 
db.foo.find();             #对于当前数据库中的foo集合进行数据查找（由于没有条件，会列出所有数据） 
db.foo.find( { a : 1 } );  #对于当前数据库中的foo集合进行查找，条件是数据中有一个属性叫a，且a的值为1
db.foo.count()                统计表的行数    
db.foo.dataSize()        统计表数据的大小    
db.foo.distinct( key ) - eg. db.foo.distinct( 'x' )                按照给定的条件除重    
db.foo.drop() drop the collection 删除表    
db.foo.dropIndex(name)  删除指定索引    
db.foo.dropIndexes() 删除所有索引  

db.stats()
db.foo.help()
db.user_metainfo.help()
db.user_metainfo.find();

```
