title: ansible入门
date: '2019-09-02 15:10:59'
updated: '2019-09-02 15:10:59'
tags: [ansible, Linux]
permalink: /articles/2019/09/02/1567408258989.html
---
1. 现在您已经阅读了安装指南并安装了Ansible，现在是时候开始使用一些ad-hoc命令了。

我们首先展示的不是Ansible的强大配置/部署/编排功能。这些功能由剧本处理，这些剧本在单独的章节中介绍。

本节介绍如何最初运行Ansible。一旦您理解了这些概念，请阅读Ad-Hoc命令简介以获取更多详细信息，然后您就可以开始学习有关Playbooks的内容并探索最有趣的部分了！

2. 远程连接信息
在我们开始之前，了解Ansible如何通过SSH协议与远程计算机进行通信非常重要。

默认情况下，Ansible将尽可能使用本机OpenSSH进行远程通信。这样可以启用ControlPersist（性能功能），Kerberos和~/.ssh/config跳转主机设置等选项。但是，当使用Enterprise Linux 6操作系统作为控制机器（Red Hat Enterprise Linux和CentOS等衍生产品）时，OpenSSH的版本可能太旧而无法支持ControlPersist。在这些操作系统上，Ansible将回归使用名为'paramiko'的OpenSSH的高质量Python实现。如果您希望使用Kerberized SSH等功能，请考虑使用Fedora，macOS或Ubuntu作为控制计算机，直到您的平台可以使用较新版本的OpenSSH。

有时您会遇到不支持SFTP的设备。这种情况很少见，但如果发生这种情况，您可以在配置Ansible中切换到SCP模式。

与远程计算机通话时，Ansible默认假设您使用的是SSH密钥。鼓励使用SSH密钥，但也可以通过提供选项在需要时使用密码验证--ask-pass。如果使用sudo功能，当sudo需要密码时，也提供--ask-become-pass（之前--ask-sudo-pass已弃用）。

注意

Ansible不会公开一个通道，允许用户和ssh进程之间的通信在使用ssh连接插件时手动接受密码来解密ssh密钥（这是默认设置）。使用的ssh-agent强烈建议。

虽然这可能是常识，但值得分享：任何管理系统都可以在被管理的计算机附近运行。如果您在云中运行Ansible，请考虑从该云中的计算机运行它。在大多数情况下，这将比在开放的互联网上更好地工作。

作为一个高级主题，Ansible不仅需要通过SSH远程连接。传输是可插拔的，可以选择在本地管理事物，以及管理chroot，lxc和jail容器。称为“ansible-pull”的模式也可以反转系统，并通过预定的git checkout让系统“回家”，从中央存储库中提取配置指令。

3. 你的第一个命令
现在您已经安装了Ansible，现在是时候开始使用一些基础知识了。

编辑（或创建）`/etc/ansible/hosts`并在其中放置一个或多个远程系统。您的公共SSH密钥应位于`authorized_keys`这些系统上：

```
192.0.2.50
aserver.example.org
bserver.example.org
```
这是一个inventory文件。

我们假设您使用SSH密钥进行身份验证。要设置SSH代理以避免重新输入密码，您可以执行以下操作：

```
$ ssh-agent bash
$ ssh-add ~/.ssh/id_rsa
```
（根据您的设置，您可能希望使用Ansible的--private-key选项来指定pem文件）

现在ping所有节点：

`$ ansible all -m ping`
Ansible将尝试使用您当前的用户名远程连接到计算机，就像SSH一样。要覆盖远程用户名，只需使用'-u'参数。

如果您想访问sudo模式，还有标志可以执行此操作：

```
# as bruce
$ ansible all -m ping -u bruce
# as bruce, sudoing to root (sudo is default method)
$ ansible all -m ping -u bruce --become
# as bruce, sudoing to batman
$ ansible all -m ping -u bruce --become --become-user batman
```
如果您碰巧想要使用sudo替换，可以在Ansible的配置中修改sudo实现（以及更改当前用户的其他方法）。传递给sudo的标志（如-H）也可以设置。

现在在所有节点上运行实时命令：

`$ ansible all -a "/bin/echo hello"`
恭喜！您刚刚使用Ansible联系了您的节点。现在很快就会：阅读Ad-Hoc命令简介中的更多实际案例，探索可以使用不同模块执行的操作，并了解Ansible 使用Playbooks语言。Ansible不仅仅是运行命令，它还具有强大的配置管理和部署功能。还有更多要探索的内容，但您已经拥有一个完全可用的基础架构！

提示

运行命令时，可以使用“localhost”或“127.0.0.1”指定本地服务器作为服务器名称。

例：

`$ ansible localhost -m ping -e 'ansible_python_interpreter="/usr/bin/env python"'`
您可以通过将其添加到清单文件中来明确指定localhost：

`localhost ansible_connection=local ansible_python_interpreter="/usr/bin/env python"`


* 主机密钥检查
Ansible默认启用主机密钥检查。

如果重新安装主机并且在'known_hosts'中具有不同的密钥，则会在纠正之前产生错误消息。如果主机最初不在'known_hosts'中，这将导致提示确认密钥，如果使用Ansible，例如cron，则会产生交互式体验。你可能不想要这个。

如果您了解其含义并希望禁用此行为，则可以通过编辑/etc/ansible/ansible.cfg或~/.ansible.cfg：

```
[defaults]
host_key_checking = False
```
或者，这可以由 ANSIBLE_HOST_KEY_CHECKING 环境变量：

`$ export ANSIBLE_HOST_KEY_CHECKING=False`
另请注意，paramiko模式下的主机密钥检查速度相当慢，因此在使用此功能时也建议切换到“ssh”。

Ansible将在远程系统日志中记录远程系统上的模块参数的一些信息，除非任务或游戏标记为“no_log：True”属性。这将在后面解释。

要在控制计算机上启用基本日志记录，请参阅配置Ansible文档并设置“log_path”配置文件设置。


