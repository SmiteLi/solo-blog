title: ansible-config命令
date: '2019-09-02 15:20:12'
updated: '2019-09-02 15:20:12'
tags: [ansible]
permalink: /articles/2019/09/02/1567408812395.html
---
ansible-config 命令：https://docs.ansible.com/ansible/latest/cli/ansible-config.html

Synopsis
ansible-config [dump|list|view] [--help] [options] [ansible.cfg]
Description
Config command line class

Common Options
--version
show program’s version number, config file location, configured module search path, module location, executable location and exit

-c <CONFIG_FILE>, --config <CONFIG_FILE>
path to configuration file, defaults to first file found in precedence.

-h, --help
show this help message and exit

-v, --verbose
verbose mode (-vvv for more, -vvvv to enable connection debugging)

Actions
dump
Shows the current settings, merges ansible.cfg if specified

--only-changed
Only show configurations that have changed from the default

view
Displays the current config file

list
list all current configs reading lib/constants.py and shows env and config file setting names

Environment
The following environment variables may be specified.

ANSIBLE_CONFIG – Override the default ansible config file

Many more are available for most options in ansible.cfg

Files
/etc/ansible/ansible.cfg – Config file, used if present

~/.ansible.cfg – User config file, overrides the default config if present


