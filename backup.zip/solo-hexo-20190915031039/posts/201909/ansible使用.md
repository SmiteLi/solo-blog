title: ansible使用
date: '2019-09-02 08:26:19'
updated: '2019-09-02 08:26:19'
tags: [Linux, ansible]
permalink: /articles/2019/09/02/1567383979702.html
---
```
ansible tifsso -m shell -a "ps -ef | grep -E 'api|srv'"

cd /data/solution
rsync -av  --delete microsso1/ microsso2/

~~~~
ansible tifsso -m shell -a "ps -ef | grep api"  
ansible tifsso -m shell -a "ps -ef | grep srv"  
ansible tifsso -m shell -a "ps -ef | grep -E 'srv|api'"  
ansible tifsso -m shell -a "netstat -lntp | grep -E 'srv|api|tifsso|consul'"  
ansible tifsso -m shell -a "tail -n10 /data/solution/tifsso/log/console_output.log"  
  
ansible tifsso -m shell -a "/data/solution/tifsso/bin/stop.sh"  
ansible tifsso -m shell -a "tail -n10 /data/solution/tifsso/log/console_output.log"  
ansible tifsso -m shell -a "df -hT"  
  
ansible oldtifsso -m shell -a "ps -ef | grep -E 'srv|api'"  
ansible oldtifsso -m shell -a "du -h --max-depth=1 /data/"  
ansible oldtifsso -m shell -a "ls -al /data/solution/tifsso/page/"
```
