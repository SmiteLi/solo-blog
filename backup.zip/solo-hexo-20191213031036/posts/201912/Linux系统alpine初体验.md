title: Linux系统alpine初体验
date: '2019-12-11 11:09:15'
updated: '2019-12-11 11:09:15'
tags: [Linux]
permalink: /articles/2019/12/11/1576033755726.html
---
## 1. virtual box进行安装
1.1 alpine官网下载最新稳定版镜像
1.2 使用vbox进行安装。光盘加载下载的iso，网络添加多一块网卡，用作后面与宿主机网络通信，如下图：
![image.png](https://img.hacpai.com/file/2019/12/image-e98e6a07.png)

## 2. 登录使用
启动后，直接输入root即可以root用户登录，无须密码。

2.1 设置root密码为root
`echo 'root:root' |chpasswd`

## 3. 设置网络：
`vi /etc/network/interfaces`
为eth0和eth1网卡设置如下：
```
auto lo
iface lo inet loopback

auto eth0
iface eth0 inet dhcp
  hostname localhost
auto eth1
iface eth1 inet static
  address 192.168.56.200
  netmask 255.255.255.0
  gateway 192.168.56.1

```
设置完成后，
```
service networking start/stop/restart
```

## 4. 安装sshd服务
`apk add --no-cache openssh`
配置sshd服务:
```
sed -i "s/#PermitRootLogin.*/PermitRootLogin yes/g" /etc/ssh/sshd_config
```
重启sshd服务
`service sshd restart`

## 5. 使用putty，xshell等ssh连接工具连上alpine：
![image.png](https://img.hacpai.com/file/2019/12/image-98ce09b4.png)

