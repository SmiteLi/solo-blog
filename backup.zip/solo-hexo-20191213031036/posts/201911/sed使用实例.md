title: sed 使用实例
date: '2019-11-04 10:50:22'
updated: '2019-11-04 10:59:00'
tags: [Linux, sed]
permalink: /articles/2019/11/04/1572835822714.html
---
## 1. 增加
```
增加一行：
行前增加：sed '1i bind 127.0.0.1' redis_*/*conf
行后增加：sed '1a bind 127.0.0.1' redis_*/*conf
增加多行
sed '1a bind 127.0.0.1\
port 6379' redis_*/*conf
```
## 2.替换
整行替换
```
nl /etc/passwd | sed '2,5c thesentensetochange'
nl /etc/passwd | sed 's/1/2/g'
```
## 3.删除
nl /etc/passwd | sed '2,5d'
