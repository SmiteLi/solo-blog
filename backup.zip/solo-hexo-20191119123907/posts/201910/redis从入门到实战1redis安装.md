title: redis从入门到实战（1）-redis安装
date: '2019-10-20 21:45:47'
updated: '2019-10-20 22:01:20'
tags: [redis]
permalink: /articles/2019/10/20/1571579147004.html
---
# redis从入门到实战（1）-redis安装

## 1.redis是什么？
REmote DIctionary Server(Redis) 是一个由Salvatore Sanfilippo写的key-value存储系统。

Redis是一个开源的使用ANSI C语言编写、遵守BSD协议、支持网络、可基于内存亦可持久化的日志型、Key-Value数据库，并提供多种语言的API。

它通常被称为数据结构服务器，因为值（value）可以是 字符串(String), 哈希(Hash), 列表(list), 集合(sets) 和 有序集合(sorted sets)等类型。

## 2. 安装redis

本次安装的redis为稳定版：redis-5.0.5。想要了解当前最新稳定版本为多少，访问[redis官网](https://redis.io/)。更多其他历史版本请访问[redis历史版本](https://redis.io/download)

### 2.1 按照步骤如下
```
1. 下载安装包：
$ wget http://download.redis.io/releases/redis-5.0.5.tar.gz
或者
curl -O http://download.redis.io/releases/redis-5.0.5.tar.gz
2. 解压压缩包：
$ tar xzf redis-5.0.5.tar.gz
3. 进入redis-5.0.5的目录
$ cd redis-5.0.5
4. 开始构建：
$ make
```

经过以上步骤，生成的redis程序放在 src 目录。下面我们开始运行redis：

```bash
# src/redis-server
12961:C 20 Oct 2019 21:11:24.643 # oO0OoO0OoO0Oo Redis is starting oO0OoO0OoO0Oo
12961:C 20 Oct 2019 21:11:24.643 # Redis version=5.0.5, bits=64, commit=00000000, modified=0, pid=12961, just started
12961:C 20 Oct 2019 21:11:24.643 # Warning: no config file specified, using the default config. In order to specify a config file use src/redis-server /path/to/redis.conf
                _._                                                  
           _.-``__ ''-._                                             
      _.-``    `.  `_.  ''-._           Redis 5.0.5 (00000000/0) 64 bit
  .-`` .-```.  ```\/    _.,_ ''-._                                   
 (    '      ,       .-`  | `,    )     Running in standalone mode
 |`-._`-...-` __...-.``-._|'` _.-'|     Port: 6379
 |    `-._   `._    /     _.-'    |     PID: 12961
  `-._    `-._  `-./  _.-'    _.-'                                   
 |`-._`-._    `-.__.-'    _.-'_.-'|                                  
 |    `-._`-._        _.-'_.-'    |           http://redis.io        
  `-._    `-._`-.__.-'_.-'    _.-'                                   
 |`-._`-._    `-.__.-'    _.-'_.-'|                                  
 |    `-._`-._        _.-'_.-'    |                                  
  `-._    `-._`-.__.-'_.-'    _.-'                                   
      `-._    `-.__.-'    _.-'                                       
          `-._        _.-'                                           
              `-.__.-'                                               

12961:M 20 Oct 2019 21:11:24.646 # WARNING: The TCP backlog setting of 511 cannot be enforced because /proc/sys/net/core/somaxconn is set to the lower value of 128.
12961:M 20 Oct 2019 21:11:24.646 # Server initialized
12961:M 20 Oct 2019 21:11:24.646 * Ready to accept connections
```

上面是我运行的结果。

显然程序是放在前台执行，我们如果想要连接上redis的话，那就要再打开一个终端窗口，然后执行以下命令：
```
# src/redis-cli
127.0.0.1:6379> set foo bar
OK
127.0.0.1:6379> get foo
"bar"
127.0.0.1:6379> 
```

现在，我们的安装就已经完成。

## 3. 让redis在后台运行

虽然我们已经安装好了redis，但是只能在前台运行，一旦关闭了终端窗口，redis也就停止运行了。那么，我们应该怎么让redis在后台运行呢？

### 3.1 把redis添加到环境变量PATH中

为了能够在任意目录都能启动redis程序，我们把redis程序安装到PATH环境变量指向的目录。操作如下：
```bash
make install
which redis-server
```
可以看到redis-server安装到了`/usr/local/bin/redis-server`。再看一下，可以发现redis有以下程序：
```
$ ll /usr/local/bin/redis-*
-rwxr-xr-x. 1 root root 4366600 Oct 20 21:17 /usr/local/bin/redis-benchmark
-rwxr-xr-x. 1 root root 8111808 Oct~~~~ 20 21:17 /usr/local/bin/redis-check-aof
-rwxr-xr-x. 1 root root 8111808 Oct 20 21:17 /usr/local/bin/redis-check-rdb
-rwxr-xr-x. 1 root root 4806832 Oct 20 21:17 /usr/local/bin/redis-cli
lrwxrwxrwx. 1 root root      12 Oct 20 21:17 /usr/local/bin/redis-sentinel -> redis-server
-rwxr-xr-x. 1 root root 8111808 Oct 20 21:17 /usr/local/bin/redis-server

```

### 3.2 准备配置文件：redis.conf

如果你留心第2节运行redis-server时的输出信息，你会发现这么一句话：
`Warning: no config file specified, using the default config. In order to specify a config file use src/redis-server /path/to/redis.conf`

那么我们为redis准备一个配置文件 redis.conf，如下：

```conf
# 只有本机能访问:
bind 127.0.0.1 
# yes表示以后台模式启动redis:
daemonize yes
# 持久化数据时，开启appendonly模式:
appendonly yes 
```

准备好配置文件后，下面我们启动redis：
```
# redis-server ./redis.conf 
1850:C 20 Oct 2019 21:34:27.334 # oO0OoO0OoO0Oo Redis is starting oO0OoO0OoO0Oo
1850:C 20 Oct 2019 21:34:27.334 # Redis version=5.0.5, bits=64, commit=00000000, modified=0, pid=1850, just started
1850:C 20 Oct 2019 21:34:27.334 # Configuration loaded
```
可以看到，redis已经是在后台启动了。下面我们再次连接redis看下是否正常：
```
# redis-cli 
127.0.0.1:6379> get foo
(nil)
127.0.0.1:6379> set foo bar
OK
127.0.0.1:6379> get foo
"bar"
```
可以看到已经正常。
>注意，在下载的安装包中，已经有一个redis.conf的官方配置文件，每一项参数都有具体的说明。感兴趣的读者可以先去看看，或者跟着我的脚步，后面一个一个再了解。

### 3.3 关闭redis


redis后台服务器的关闭命令：`redis-cli shutdown`

## 4. 一些参考命令
```
# redis-server --help
Usage: ./redis-server [/path/to/redis.conf] [options]
       ./redis-server - (read config from stdin)
       ./redis-server -v or --version
       ./redis-server -h or --help
       ./redis-server --test-memory <megabytes>

Examples:
       ./redis-server (run the server with default conf)
       ./redis-server /etc/redis/6379.conf
       ./redis-server --port 7777
       ./redis-server --port 7777 --replicaof 127.0.0.1 8888
       ./redis-server /etc/myredis.conf --loglevel verbose

Sentinel mode:
       ./redis-server /etc/sentinel.conf --sentinel

# redis-cli --help
Examples:
  cat /etc/passwd | redis-cli -x set mypasswd
  redis-cli get mypasswd
  redis-cli -r 100 lpush mylist x
  redis-cli -r 100 -i 1 info | grep used_memory_human:
  redis-cli --eval myscript.lua key1 key2 , arg1 arg2 arg3
  redis-cli --scan --pattern '*:12345*'

$ redis-cli -h host -p port -a password

有时候会有中文乱码，要在 redis-cli 后面加上 --raw 如： redis-cli --raw
```

## 5. 下一节是？

下一节我们讨论下如何使用redis。
