title: ssh使用私钥文件登陆远程服务器
date: '2019-09-27 17:43:36'
updated: '2019-09-27 17:43:36'
tags: [Linux]
permalink: /articles/2019/09/27/1569577416252.html
---
# ssh使用私钥文件登陆远程服务器
A服务器：192.168.10.1
B服务器：192.168.10.2
A服务器通过B服务器的私钥，免密登陆B服务器

## 1. 准备私钥文件
在B服务器生成密钥：B.pri.key

## 2. 把B.pri.key上传到A服务器以下目录
~/.ssh/.server_keys

修改私钥文件为只有本用户~~~~可读：
chmod 400 B.pri.key

## 3. 使用私钥登陆B服务器：
在A服务器
`ssh -i ~/.ssh/.server_keys/B.pri.key root@192.168.10.2`

