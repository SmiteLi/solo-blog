title: consul的docker cluster使用
date: '2019-10-31 14:26:14'
updated: '2019-10-31 14:26:14'
tags: [consul, docker]
permalink: /articles/2019/10/31/1572503173904.html
---
## 1. 运行3个dev节点：
server：
```
$ docker run -d --name=dev-consul -e CONSUL_BIND_INTERFACE=eth0 consul -ui
```
client：
```
$ docker run -d -e CONSUL_BIND_INTERFACE=eth0 consul agent -dev -join=172.17.0.7
... server 2 starts
$ docker run -d -e CONSUL_BIND_INTERFACE=eth0 consul agent -dev -join=172.17.0.7
... server 3 starts
```
查看集群状态：
```
docker exec -t dev-consul consul members
```

## 2. Running Consul Agent in Client Mode
```
$  docker run -d --net=host -e 'CONSUL_LOCAL_CONFIG={"leave_on_terminate": true}' consul agent -bind=<external ip> -retry-join=<root agent ip>
==> Starting Consul agent...
==> Starting Consul agent RPC...
==> Consul agent running!
         Node name: 'linode'
        Datacenter: 'dc1'
            Server: false (bootstrap: false)
       Client Addr: 127.0.0.1 (HTTP: 8500, HTTPS: -1, DNS: 8600, RPC: 8400)
      Cluster Addr: <external ip> (LAN: 8301, WAN: 8302)
    Gossip encrypt: false, RPC-TLS: false, TLS-Incoming: false
             Atlas: <disabled>
...
```
验证运行：
```
curl http://localhost:8500/v1/health/service/consul?pretty
```
```
dig @localhost -p 8600 consul.service.consul
```
通过bridge network暴露端口：
```
docker run -d --net=host consul agent -bind=<external ip> -client=<bridge ip> -retry-join=<root agent ip>
```
Consul will also accept the `-client=0.0.0.0` option to bind to all interfaces.

## 3. Running Consul Agent in Server Mode
```
$ docker run -d --net=host -e 'CONSUL_LOCAL_CONFIG={"skip_leave_on_interrupt": true}' consul agent -server -bind=<external ip> -retry-join=<root agent ip> -bootstrap-expect=<number of server agents>
```
