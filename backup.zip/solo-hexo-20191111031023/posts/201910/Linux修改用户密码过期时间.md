title: Linux修改用户密码过期时间
date: '2019-10-30 19:08:07'
updated: '2019-10-30 19:08:07'
tags: [Linux]
permalink: /articles/2019/10/30/1572433687656.html
---
chage -l  xxxx
chage -E -1 xxxx
chage -M 99999 xxxxx
