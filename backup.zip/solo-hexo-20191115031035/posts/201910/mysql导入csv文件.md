title: mysql导入csv文件
date: '2019-10-07 19:35:23'
updated: '2019-10-07 19:35:23'
tags: [mysql]
permalink: /articles/2019/10/07/1570448123854.html
---
参考资料：
https://blog.csdn.net/kikajack/article/details/80529640
https://dev.mysql.com/doc/refman/5.7/en/load-data.html

```
LOAD DATA INFILE 'data.txt' INTO TABLE db2.my_table;
LOAD DATA INFILE 'data.txt' INTO TABLE db2.my_table FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\n';
```
