title: the skill of docker
date: '2019-09-16 14:50:18'
updated: '2019-09-16 14:50:18'
tags: [docker]
permalink: /articles/2019/09/16/1568616618160.html
---

## one
```
如果我们结合这两个命令以及 ssh 甚至 pv 的话，利用 Linux 强大的管道，我们可以写一
个命令完成从一个机器将镜像迁移到另一个机器，并且带进度条的功能：
docker save <镜像名> | bzip2 | pv | ssh <用户名>@<主机名> 'cat | docker load'
```

## two
```

```
