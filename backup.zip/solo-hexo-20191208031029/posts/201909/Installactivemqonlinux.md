title: Install activemq on linux
date: '2019-09-18 14:20:55'
updated: '2019-09-18 14:20:55'
tags: [activemq]
permalink: /articles/2019/09/18/1568787655839.html
---
![](https://img.hacpai.com/bing/20190607.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 1.  reference:http://activemq.apache.org/getting-started

## 2. step by step:
```
cd [activemq_install_dir]/bin
./activemq console


cd [activemq_install_dir]/bin
./activemq start

[http://127.0.0.1:8161/admin/](http://127.0.0.1:8161/admin/)
admin/admin

log file :
[activemq_install_dir]/data/activemq.log

listen port:
netstat -nl|grep 61616


```

## 3. admin activemq
```
cd [activemq_install_dir]/bin
./activemq stop


```

