title: curl获取网页响应时间
date: '2019-11-20 19:25:58'
updated: '2019-11-20 19:25:58'
tags: [Linux]
permalink: /articles/2019/11/20/1574249158070.html
---
```
for ((i=1;i<=18;i++));do time=`curl -s -o /dev/null -w "%{time_total}\n" https://wg.gddj.gov.cn/gddjy/img/Banner.81df7728.png`;echo "耗时: $time";done
```
