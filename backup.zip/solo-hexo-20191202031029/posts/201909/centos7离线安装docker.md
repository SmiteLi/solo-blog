title: centos7离线安装docker
date: '2019-09-29 14:39:19'
updated: '2019-09-29 14:41:26'
tags: [docker]
permalink: /articles/2019/09/29/1569739159551.html
---
# docker离线安装


## 1. 下载安装包

docker离线安装包下载：[下载链接](https://download.docker.com/linux/static/stable/)

## 2. 执行安装脚本


## 3. 验证安装

## 4. 可能报错



```sh
[root@host-172-16-102-29 tmp]# systemctl start docker
Job for docker.service failed because start of the service was attempted too often. See "systemctl status docker.service" and "journalctl -xe" for details.
To force a start use "systemctl reset-failed docker.service" followed by "systemctl start docker.service" again.

按照提示，
systemctl reset-failed docker.service
systemctl start docker.service
```
