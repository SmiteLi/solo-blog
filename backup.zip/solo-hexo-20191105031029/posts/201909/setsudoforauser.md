title: set sudo for a user
date: '2019-09-19 21:43:46'
updated: '2019-09-19 21:44:17'
tags: [Linux]
permalink: /articles/2019/09/19/1568900626840.html
---
1. 在root权限下，useradd只是创建了一个用户名，如 （useradd  +用户名 ），它并没有在/home目录下创建同名文件夹，也没有创建密码，因此利用这个用户登录系统，是登录不了的，为了避免这样的情况出现，可以用 （useradd -m +用户名）的方式创建，它会在/home目录下创建同名文件夹，然后利用（ passwd + 用户名）为指定的用户名设置密码。

2. 可以直接利用adduser创建新用户（adduser +用户名）这样在/home目录下会自动创建同名文件夹
```
adduser user01
```
3. 配置权限
```
实例2：让普通用户user01具有所有超级用户的权限而又不用输入密码

[root@test ~]# visudo  
user01  ALL=(ALL) NOPASSWD: ALL

#root    ALL=(ALL)       ALL
```
