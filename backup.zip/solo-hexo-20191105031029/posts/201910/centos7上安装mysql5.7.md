title: centos7上安装mysql5.7
date: '2019-10-07 19:41:39'
updated: '2019-10-07 19:41:39'
tags: [mysql]
permalink: /articles/2019/10/07/1570448499092.html
---
参考文档：
https://dev.mysql.com/doc/mysql-yum-repo-quick-guide/en/


