title: mongodb副本集主从手动切换
date: '2019-11-28 21:05:40'
updated: '2019-11-28 21:05:40'
tags: [mongo]
permalink: /articles/2019/11/28/1574946340445.html
---
一、方法一rs.setpDown()

**将Primary节点降级为Secondary节点**

myapp:PRIMARY> rs.stepDown()

这个命令会让primary降级为Secondary节点，并维持60s，如果这段时间内没有新的primary被选举出来，这个节点可以要求重新进行选举。

也可手动指定时间

myapp:PRIMARY> rs.stepDown(30)

在执行完该命令后，原Secondary node3:27017升级为Primary。

二、方法二优先级设置

思路:  
1.为了保证数据的一致性，必须先关闭应用的写服务。  
2.提升要升级为Primary节点的Secondary节点的优先级。  
  
操作如下:  
  

点击(此处)折叠或打开

1. arps:PRIMARY> config=rs.conf()                //查看当前配置，存入config变量中。
2. arps:PRIMARY> config.members[0].priority = 3  //修改config变量，第三组成员的优先级为3.优先级1-100，数字越大，优先级越高
3. arps:PRIMARY> rs.reconfig(config)             //配置生效                       
4. ......
5. ......
6. 2017-12-22T15:19:56.596+0800 I NETWORK trying reconnect to 127.0.0.1:27017 (127.0.0.1) failed
7. 2017-12-22T15:19:56.597+0800 I NETWORK reconnect 127.0.0.1:27017 (127.0.0.1) ok
9. arps:SECONDARY> rs.conf()                    //查看当前配置
10. {
11.         "_id" : "arps",
12.         "version" : 4,
13.         "members" : [
14.                 {
15.                         "_id" : 0,
16.                         "host" : "172.17.4.37:27017",
17.                         "arbiterOnly" : false,
18.                         "buildIndexes" : true,
19.                         "hidden" : false,
20.                         "priority" : 1,
21.                         "tags" : {
23.                         },
24.                         "slaveDelay" : 0,
25.                         "votes" : 1
26.                 },
27.                 {
28.                         "_id" : 1,
29.                         "host" : "172.17.4.38:27017",
30.                         "arbiterOnly" : false,
31.                         "buildIndexes" : true,
32.                         "hidden" : false,
33.                         "priority" : 1,
34.                         "tags" : {
36.                         },
37.                         "slaveDelay" : 0,
38.                         "votes" : 1
39.                 },
40.                 {
41.                         "_id" : 2,
42.                         "host" : "172.17.4.39:27017",
43.                         "arbiterOnly" : false,
44.                         "buildIndexes" : true,
45.                         "hidden" : false,
46.                         "priority" : 3,             //优先级变为3
47.                         "tags" : {
49.                         },
50.                         "slaveDelay" : 0,
51.                         "votes" : 1
52.                 }
53.         ],
54.         "settings" : {
55.                 "chainingAllowed" : true,
56.                 "heartbeatTimeoutSecs" : 10,
57.                 "getLastErrorModes" : {
59.                 },
60.                 "getLastErrorDefaults" : {
61.                         "w" : 1,
62.                         "wtimeout" : 0
63.                 }
64.         }
65. }
67. arps:SECONDARY> rs.status()
68. {
69.         "set" : "arps",
70.         "date" : ISODate("2017-12-22T07:25:04.641Z"),
71.         "myState" : 2,
72.         "syncingTo" : "172.17.4.39:27017",
73.         "members" : [
74.                 {
75.                         "_id" : 0,
76.                         "name" : "172.17.4.37:27017",
77.                         "health" : 1,
78.                         "state" : 2,
79.                         "stateStr" : "SECONDARY",
80.                         "uptime" : 7597536,
81.                         "optime" : Timestamp(1513927481, 3),
82.                         "optimeDate" : ISODate("2017-12-22T07:24:41Z"),
83.                         "syncingTo" : "172.17.4.39:27017",
84.                         "configVersion" : 4,
85.                         "self" : true
86.                 },
87.                 {
88.                         "_id" : 1,
89.                         "name" : "172.17.4.38:27017",
90.                         "health" : 1,
91.                         "state" : 2,
92.                         "stateStr" : "SECONDARY",
93.                         "uptime" : 7597426,
94.                         "optime" : Timestamp(1513927481, 3),
95.                         "optimeDate" : ISODate("2017-12-22T07:24:41Z"),
96.                         "lastHeartbeat" : ISODate("2017-12-22T07:25:02.961Z"),
97.                         "lastHeartbeatRecv" : ISODate("2017-12-22T07:25:04.091Z"),
98.                         "pingMs" : 0,
99.                         "syncingTo" : "172.17.4.39:27017",
100.                         "configVersion" : 4
101.                 },
102.                 {
103.                         "_id" : 2,
104.                         "name" : "172.17.4.39:27017",
105.                         "health" : 1,
106.                         "state" : 1,
107.                         "stateStr" : "PRIMARY",    //最后一个节点升级为PRIMARY
108.                         "uptime" : 3202,
109.                         "optime" : Timestamp(1513927481, 3),
110.                         "optimeDate" : ISODate("2017-12-22T07:24:41Z"),
111.                         "lastHeartbeat" : ISODate("2017-12-22T07:25:02.951Z"),
112.                         "lastHeartbeatRecv" : ISODate("2017-12-22T07:25:04.344Z"),
113.                         "pingMs" : 0,
114.                         "electionTime" : Timestamp(1513927190, 2),
115.                         "electionDate" : ISODate("2017-12-22T07:19:50Z"),
116.                         "configVersion" : 4
117.                 }
118.         ],
119.         "ok" : 1
120. }
