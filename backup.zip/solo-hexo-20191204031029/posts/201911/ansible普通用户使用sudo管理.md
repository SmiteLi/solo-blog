title: ansible普通用户使用sudo管理
date: '2019-11-04 15:00:41'
updated: '2019-11-04 15:00:41'
tags: [ansible]
permalink: /articles/2019/11/04/1572850841277.html
---
## hosts文件
```
[redis]
# the redis of tyrz
192.168.0.1 ansible_user=tyrz ansible_password=T@369.com ansible_become_user=root ansible_become_password=123456
192.168.0.2 ansible_user=tyrz ansible_password=T@369.com ansible_become_user=root ansible_become_password=123456
192.168.0.3 ansible_user=tyrz ansible_password=T@369.com ansible_become_user=root ansible_become_password=123456
```

## 使用：
```
ansible redis -m shell -a "chage -l tyrz" --become
```

## 参考：
```
ansible tyrz -m shell -a 'chage -E -1 tyrz;chage -M 99999 tyrz' --become
chage -E -1 tyrz;chage -M 99999 tyrz

ansible redis -m shell -a "chage -l tyrz" --become --become-user root [--ask-become-pass]

ansible_become_password=Ysspaas@2019

ansible oldtifsso -m shell -a "ls /root" --become
ansible oldtifsso -m synchronize -a "src=/data/solution/tifsso/page/ dest=/data/solution/tifsso/page/ archive=yes delete=yes" --become
```
