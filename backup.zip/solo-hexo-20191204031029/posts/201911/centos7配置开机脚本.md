title: centos7配置开机脚本
date: '2019-11-14 11:55:20'
updated: '2019-11-14 11:55:20'
tags: [Linux]
permalink: /articles/2019/11/14/1573703720152.html
---
## 步骤

1. 在/etc/init.d目录放置脚本
2. 在对应的运行等级目录放置脚本软连接

实例如下：
```
    ln -sf {{work_dir}}/bin/start.sh /etc/init.d/tyrz-tifsso-start.sh
    ln -sf /etc/init.d/tyrz-tifsso-start.sh /etc/rc.d/rc3.d/S95tyrz-tifsso-start.sh
```
S95tyrz-tifsso-start.sh，S95表示 第95的start

K95tyrz-tifsso-start.sh，K95表示95的kill
