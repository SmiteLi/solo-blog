title: Ansible从入门到实战（3）-Ansible模块初接触
date: '2019-10-08 19:10:45'
updated: '2019-10-08 19:10:45'
tags: [ansible]
permalink: /articles/2019/10/08/1570533045056.html
---
# Ansible从入门到实战（3）-Ansible模块初接触

module，模块，是Ansible功能实现的灵魂。Ansible众多的功能就是一个一个的module实现的。多个module的组合能让我们写出自动化运维的脚本，也就是后面会

## 一、一个命令的简单分析

让我们来看下上一节执行的命令`ansible all -m ping`，对应这个命令，你应该知道的：
- all，这个参数指的是`/etc/ansible/hosts`文件中所有的主机。如果你按照上一节的教程配置的话，我们可以把 all 替换为 node1 ，这样意思是本次命令针对的是 node1 这个组别的主机
- \-m 这个参数指明要使用哪个模块，上述命令意思是使用 ping 模块

接下来我们把命令改为`ansible node1 -m ping`测试下，结果如下：

```bash
[root@localhost ~]# ansible node1 -m ping
localhost | SUCCESS => {
    "changed": false, 
    "ping": "pong"
}
apple | SUCCESS => {
    "ansible_facts": {
        "discovered_interpreter_python": "/usr/bin/python"
    }, 
    "changed": false, 
    "ping": "pong"
}
```
注意：如果不用 \-m指定执行的模块，默认使用 command 模块

>Normally commands take a `-m` for module name, but the default module name is ‘command’

## 二、ad-hoc command ：特设命令

什么是ad-hoc command？我们来看下官方的解释：

>An ad-hoc command is something that you might type in to do something really quick, but don’t want to save for later.

可以看出，ad-hoc command 就是用来完成一些简单任务的命令

## 三、常用的 ad-hoc 有哪些？

- 3.1 文件传输

```
- 传输文件：
$ ansible node1 -m copy -a "src=/etc/hosts dest=/tmp/hosts"

- 修改文件用户和权限
$ ansible node1 -m file -a "dest=/srv/foo/a.txt mode=600"
$ ansible node1 -m file -a "dest=/srv/foo/b.txt mode=600 owner=mdehaan group=mdehaan"

- 类似 mkdir -p 的操作：
ansible node1 -m file -a "dest=/path/to/c mode=755 owner=mdehaan group=mdehaan state=directory"

- 递归删除目录和文件：
$ ansible node1 -m file -a "dest=/path/to/c state=absent"
```

以上命令，我在被管理机器上`mkdir -p /tmp/test/user01`建立了测试文件夹，然后在控制节点执行`ansible apple -m file -a "dest=/tmp/test/user01 state=absent"`，其中apple是我在配置文件里设置的主机名，结果如下：

```
[root@localhost ~]# ansible apple -m file -a "dest=/tmp/test/user01 state=absent"
apple | CHANGED => {
    "ansible_facts": {
        "discovered_interpreter_python": "/usr/bin/python"
    }, 
    "changed": true, 
    "path": "/tmp/test/user01", 
    "state": "absent"
}
```

- 3.2 管理系统软件包

确认软件是否安装，不会升级：
`$ ansible webservers -m yum -a "name=acme state=present"`

确认软件安装为确定版本:
`$ ansible webservers -m yum -a "name=acme-1.5 state=present"`

确认软件安装为最新版本:
`$ ansible webservers -m yum -a "name=acme state=latest"`

确认软件没有安装:
`$ ansible webservers -m yum -a "name=acme state=absent"`

我执行了`ansible apple -m yum -a "name=acme state=absent"`，结果如下：
```
[root@localhost ~]# ansible apple -m yum -a "name=acme state=absent"
apple | SUCCESS => {
    "ansible_facts": {
        "discovered_interpreter_python": "/usr/bin/python"
    }, 
    "changed": false, 
    "msg": "", 
    "rc": 0, 
    "results": [
        "acme is not installed"
    ]
}
```
- 3.3 用户和用户组管理

创建用户
`$ ansible all -m user -a "name=foo password=<crypted password here>"`

删除用户
`$ ansible all -m user -a "name=foo state=absent"`

我执行了`ansible apple -m user -a "name=foo state=absent"`，结果如下：
```
[root@localhost ~]# ansible apple -m user -a "name=foo state=absent"
apple | SUCCESS => {
    "ansible_facts": {
        "discovered_interpreter_python": "/usr/bin/python"
    },
    "changed": false,
    "name": "foo",
    "state": "absent"
}
```

- 3.4 服务管理

确认服务已经开启:
`$ ansible apple -m service -a "name=httpd state=started"`

重启服务：
`$ ansible apple -m service -a "name=httpd state=restarted"`

关闭服务：
`$ ansible apple -m service -a "name=httpd state=stopped"`

我执行了`ansible apple -m service -a "name=httpd state=stopped"`，结果如下：
```
[root@localhost ~]# ansible apple -m service -a "name=httpd state=stopped"
apple | FAILED! => {
    "ansible_facts": {
        "discovered_interpreter_python": "/usr/bin/python"
    },
    "changed": false,
    "msg": "Could not find the requested service httpd: host"
}
```
我的被管理机器没有安装httpd，所以返回的结果说找不到httpd服务

## 四、下一节是？

下一节将会学习一些常用的Ansible module（模块）


