title: git源码编译
date: '2019-11-19 11:54:56'
updated: '2019-11-19 11:54:56'
tags: [git]
permalink: /articles/2019/11/19/1574135696340.html
---
```
1．首先安装gcc编译工具和git依赖  
yum install gcc gcc-c++ kernel-devel curl-devel expat-devel gettext-devel openssl-devel zlib-devel  perl-ExtUtils-MakeMaker
2．上传git源码到服务器解压  
curl -O https://mirrors.edge.kernel.org/pub/software/scm/git/git-2.9.5.tar.xz
3．编译安装git工具  
./configure --prefix=/usr/local   #root用户执行
make -j 4 && make install
4. 配置当前git为最新
cp /bin/git /bin/git.bak
ln -sf /usr/local/bin/git /bin/git
```
