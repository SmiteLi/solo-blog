title: linux审计工具lynis
date: '2019-09-20 10:59:01'
updated: '2019-09-20 10:59:01'
tags: [Linux, lynis]
permalink: /articles/2019/09/20/1568948341218.html
---
## 1. 参考资料：https://cisofy.com/documentation/lynis/get-started/#first-run

## 2. 常用命令
```
### Common parameters

Lynis is started with at least one command, usually followed by one or more options.

#### Example Commands

| Command |  Description |
| audit system |  Perform a system audit |
| show commands |  Show available Lynis commands |
| show help |  Provide a help screen |
| show profiles |  Display discovered profiles |
| show settings |  List all active settings from profiles |
| show version |  Display current Lynis version |

The *show* command requires an up-to-date version of Lynis.

#### Options

| Option |  Abbreviated |  Description |
| --auditor "Given name Surname" |    |  Assign an auditor name to the audit (report) |
| --cronjob |    |  Run Lynis as cronjob (includes -c -Q) |
| --debug |    |  Show debug information, useful for troubleshooting and development |
| --help |  -h |  Shows valid parameters |
| --man-page |    |  View man page |
| --no-colors |    |  Do not use any colors |
| --pentest |    |  Perform a penetration test scan (non-privileged) |
| --quick |  -Q |  Don't wait for user input, except on errors |
| --quiet |  -q |  Only show warnings (includes --quick, but doesn't wait) |
| --reverse-colors |    |  Use a different color scheme for lighter backgrounds |
| --verbose |    |  Show more screen output |

  
**Tips**  

* If Lynis is not installed as package (with included man page), use **--man** or **nroff -man ./lynis.8**
* For systems where the shell background is light, use **--nocolors** or **--reverse-colors**
* Use command **show options** to see all available parameters of Lynis
```

## 3. report
```
During the audit process, Lynis will gather findings and other data points. This information is stored in the report file, which is by default **/var/log/lynis-report.dat**.
```
