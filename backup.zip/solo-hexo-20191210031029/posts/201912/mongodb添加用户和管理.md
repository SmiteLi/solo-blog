title: mongodb添加用户和管理
date: '2019-12-02 11:58:30'
updated: '2019-12-02 11:58:30'
tags: [mongo]
permalink: /articles/2019/12/02/1575259110437.html
---
资料：[链接](https://docs.mongodb.com/manual/tutorial/enable-authentication/)

```
use admin
db.createUser(
  {
    user: "myUserAdmin",
    pwd: passwordPrompt(), // or cleartext password
    roles: [ { role: "userAdminAnyDatabase", db: "admin" }, "readWriteAnyDatabase" ]
  }
)


mongo --port 27017  --authenticationDatabase "admin" -u "myUserAdmin" -p
```
