title: Set the bash PS1
date: '2019-09-05 16:35:12'
updated: '2019-09-05 16:35:12'
tags: [Linux]
permalink: /articles/2019/09/05/1567672512586.html
---
```
https://github.com/twolfson/sexy-bash-prompt

command as follow:
(cd /tmp && git clone --depth 1 --config core.autocrlf=false https://github.com/twolfson/sexy-bash-prompt && cd sexy-bash-prompt && make install) && source ~/.bashrc
```

