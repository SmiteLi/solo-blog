title: Linux安全保障调整
date: '2019-09-21 11:50:16'
updated: '2019-09-21 11:52:22'
tags: [Linux, lynis]
permalink: /articles/2019/09/21/1569037816233.html
---
# 等保测评前整改

## 1. 配置管理用户，禁止root登录

### 1.1 添加普通用户

```
adduser ty
echo "Ty@369.com" | passwd ty --stdin
```

### 1.2 添加sudo权限
执行命令：`visudo`

找到 root    ALL=(ALL)       ALL，在下面添加一行:
ty    ALL=(ALL)       ALL

### 1.3 使用tyrz用户登录，然后执行 `sudo ls /root` 验证是否有sudo权限

### 1.4 上面步骤通过后，禁用root登录

使用 tyrz  用户

sudo vim /etc/ssh/sshd_config

找到 *PermitRootLogin yes* 这个参数，修改为 *PermitRootLogin no*

添加尝试登录次数限制 5 次： *MaxAuthTries 5*

保存，退出vi编辑器。

重启sshd服务： sudo service sshd restart

再次使用root登录，验证是否已经禁止root登录

### 1.5 以后使用tyrz用户登录，可以使用sudo或者使用su切换到root

## 2. 配置审计用户，上传

### 2.1 配置 audit 用户：

```
adduser audit
echo "Adt@36.ty" | passwd audit --stdin
```

### 2.2 把软件lynis-2.7.5.tar.gz 上传到 /home/audit目录

解压文件：`tar -xf lynis-2.7.5.tar.gz`
然后：`cd lynis`

查看帮助：`./lynis`

执行系统审查：`./lynis audit system`

有些扫描动作需要root权限，所以可以切换到root再执行系统审查

### 2.2 每天定时审计见4.2的脚本

## 3. 升级openssh

查看openssh是否需要升级:

`yum check-update | grep ssh`

如果看到新版本，可以按照下面的命令更新：

`yum -y update 包名`，如：

`yum -y update openssh`

## 4. 系统日志备份

### 4.1 创建系统日志备份目录：

`mkdir -p /home/audit/syslogbak`

### 4.2 编写定时审计，备份系统日志脚本：

```sh
cd /home/audit
vi audit_and_syslogbak.sh
```

写入以下脚本
```bash
#!/bin/bash

# 执行系统审计
cd /home/audit/lynis
./lynis audit system > /dev/null 2>&1

# 备份系统日志
cd /var/log
tar -cJf syslogbak-`date +%F`.xz * &> /dev/null
mv syslogbak-`date +%F`.xz /home/audit/syslogbak/
```

### 4.3 定时执行上面脚本

切换到root用户，然后：
`cronta -e`

配置为每天晚上11点30分执行脚本：
```vim
30 23 * * * /bin/bash /home/audit/audit_and_syslogbak.sh
```

## 5. 数据备份

### 5.1 mongo 数据备份：

写个脚本每天备份

### 5.2 redis 数据备份：

写个脚本每天备份 redis 数据文件

