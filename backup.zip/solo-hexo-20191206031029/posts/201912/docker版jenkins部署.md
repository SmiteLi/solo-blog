title: docker版jenkins部署
date: '2019-12-04 14:09:58'
updated: '2019-12-04 14:25:52'
tags: [docker]
permalink: /articles/2019/12/04/1575439797964.html
---
## 查看文件属性
```
[root@93 jenkins]# stat /var/run/docker.sock 
  文件："/var/run/docker.sock"
  大小：0         	块：0          IO 块：4096   套接字
设备：13h/19d	Inode：105287      硬链接：1
权限：(0660/srw-rw----)  Uid：(    0/    root)   Gid：(  992/  docker)
最近访问：2019-12-04 14:16:30.391809819 +0800
最近更改：2019-11-12 10:53:13.334582969 +0800
最近改动：2019-11-12 10:53:13.335582969 +0800
创建时间：-


```

## 特权运行
```
docker run --rm -it \
  --user root\
  -v /var/run/docker.sock:/var/run/docker.sock \
  -v /usr/bin/docker:/usr/bin/docker \
  mysql \
  /bin/bash
```

## 指定用户运行
```
docker run --rm -it \
  --user "999:999"\
  -v /var/run/docker.sock:/var/run/docker.sock \
  -v /usr/bin/docker:/usr/bin/docker \
  mysql \
  /bin/bash

如果用Host当前用户的UID和GID，可以用`id`命令：

--user $(id -u):$(id -g)
```

## 运行Jenkins
```
mkdir -p /data/jenkins/jenkins_home  
chown -r 1000:1000 /data/jenkins/jenkins_home  
docker run -d --privileged -v /data/jenkins/jenkins_home:/var/jenkins_home \  
    -v /var/run/docker.sock:/var/run/docker.sock \  
    -v $(which docker):/usr/bin/docker \  
    -p 8090:8080 -p 50000:50000 jenkins/jenkins:lts
```
