title: Ansible从入门到实战（1）—— Ansible安装
date: '2019-09-02 14:36:57'
updated: '2019-10-08 15:01:51'
tags: [Linux, ansible]
permalink: /articles/2019/09/02/1567406217520.html
---
# Ansible从入门到实战（1）—— Ansible安装

本章主要介绍Ansible什么，已经Ansible的安装

## 一、Ansible是什么？

Ansible是一个“配置管理工具”也是一个“自动化运维工具”。

Ansible是一种IT自动化工具。它可以配置系统，部署软件以及协调更高级的IT任务，例如连续部署或零停机滚动更新。

Ansible 是一个能实现批量部署的自动化运维工具，基于python开发，能实现批量系统配置，批量部署程序，批量运行命令。Ansible是基于模块来运行，它本身没有任何批量部署的能力，ansible主要是提供一种批量部署的框架。
 
## 二、Ansible 的特性：

- No agent ：不需要在被管控主机上安装任何软件
- No server ：不用单独启用服务，能使用直接运行，使用时直接运行命令
- 对硬件资源占用小
- 不需要在被管控的主机上安装任何软件
- 基于模块工作
- 基于ssh工作
- 使用yaml语言
- 可实现多级指挥

## 三、Ansible的安装要求

- 控制节点（安装Ansible的服务器）：要求服务器的python版本高于2.7或者3.5
- 被管理节点（被管理的服务器）：要求服务器的python版本高于2.6或者3.5

基于以上基本要求，推荐在最新的Centos7或者Ubuntu16上安装Ansible。下面介绍在Centos7或者Ubuntu16上安装Ansible。

## 四、在 Centos7 上安装Ansible

- 4.1 安装步骤

```bash
yum install subscription-manager
sudo subscription-manager repos --enable rhel-7-server-ansible-2.8-rpms
sudo yum install ansible
```

- 4.2 验证安装

输入命令`ansible --version`进行验证。下面为我的机器输出的结果：

```
[root@localhost ~]# ansible --version
ansible 2.8.5
  config file = /etc/ansible/ansible.cfg
  configured module search path = [u'/root/.ansible/plugins/modules', u'/usr/share/ansible/plugins/modules']
  ansible python module location = /usr/lib/python2.7/site-packages/ansible
  executable location = /usr/bin/ansible
  python version = 2.7.5 (default, Jun 20 2019, 20:27:34) [GCC 4.8.5 20150623 (Red Hat 4.8.5-36)]
```

五、在 Ubuntu16.04 上安装Ansible

- 5.1 配置PPA源，并且执行下面的安装命令

```bash
$ sudo apt update
$ sudo apt install software-properties-common
$ sudo apt-add-repository --yes --update ppa:ansible/ansible
$ sudo apt install ansible
```


- 5.2 验证安装

输入命令`ansible --version`进行验证。输出信息参考 4.2 小节。

## 六、接下来是？

既然我们已经安装好了Ansible，下一节我们将会对Ansible的功能来个简单的介绍、使用。
