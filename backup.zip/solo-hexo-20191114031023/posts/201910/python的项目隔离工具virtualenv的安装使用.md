title: python的项目隔离工具virtualenv的安装使用
date: '2019-10-19 23:04:12'
updated: '2019-10-19 23:04:12'
tags: [python]
permalink: /articles/2019/10/19/1571497452381.html
---
1. Create and activate the virtual environment
    
    **For windows**
    
    ```
    py -3 -m venv .venv
    .venv\scripts\activate
    ```
    
    If the activate command generates the message "Activate.ps1 is not digitally signed. You cannot run this script on the current system.", then you need to temporarily change the PowerShell execution policy to allow scripts to run (see [About Execution Policies](https://go.microsoft.com/fwlink/?LinkID=135170) in the PowerShell documentation):
    
    ```
    Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope Process
    ```
    
    **For macOS/Linux**
    
    ```
    python3 -m venv .venv
    source .venv/bin/activate
    ```
    
2. Install the packages
    
    ```
    # Don't use with Anaconda distributions because they include matplotlib already.
    
    # macOS
    python3 -m pip install matplotlib
    
    # Windows (may require elevation)
    python -m pip install matplotlib
    
    # Linux (Debian)
    apt-get install python3-tk
    python3 -m pip install matplotlib
    ```
    
3. Select your new environment by using the **Python: Select Interpreter** command from the **Command Palette**.
    
4. Rerun the program now (with or without the debugger) and after a few moments a plot window appears with the output:
    
    ![matplotlib output](https://code.visualstudio.com/assets/docs/python/tutorial/plot-output.png)
    
5. Once you are finished, type `deactivate` in the terminal window to deactivate the virtual environment.

6. 新建文件 standardplot.py
```
import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(0, 20, 100)  # Create a list of evenly-spaced numbers over the range
plt.plot(x, np.sin(x))       # Plot the sine of each x point
plt.show()                   # Display the plot
```
按照第五点，运行本python程序。
