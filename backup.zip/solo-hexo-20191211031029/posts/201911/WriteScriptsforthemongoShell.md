title: Write Scripts for the mongo Shell
date: '2019-11-29 17:26:28'
updated: '2019-11-29 17:26:28'
tags: [mongo]
permalink: /articles/2019/11/29/1575019588800.html
---
# [参考链接](https://docs.mongodb.com/manual/tutorial/write-scripts-for-the-mongo-shell/)

## Opening New Connections
```
new Mongo()
new Mongo(<host>)
new Mongo(<host:port>)

conn = new Mongo();
db = conn.getDB("myDatabase");

db = connect("localhost:27020/myDatabase");
```

EXAMPLE

To print all items in a result cursor in [`mongo`](https://docs.mongodb.com/manual/reference/program/mongo/#bin.mongo "bin.mongo") shell scripts, use the following idiom:

```
cursor = db.collection.find();
while ( cursor.hasNext() ) {
   printjson( cursor.next() );
}
```

### Execute a JavaScript file
`mongo localhost:27017/test myjsfile.js`

```
load("myjstest.js")
```
The `load()` method accepts relative and absolute paths. If the current working directory of the [`mongo`](https://docs.mongodb.com/manual/reference/program/mongo/#bin.mongo "bin.mongo") shell is `/data/db`, and the `myjstest.js` resides in the `/data/db/scripts` directory, then the following calls within the [`mongo`](https://docs.mongodb.com/manual/reference/program/mongo/#bin.mongo "bin.mongo") shell would be equivalent:

```
load("scripts/myjstest.js")
load("/data/db/scripts/myjstest.js")
```
