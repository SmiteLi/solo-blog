title: ansible后台执行和多线程执行
date: '2019-10-08 19:08:25'
updated: '2019-10-08 19:08:25'
tags: [ansible]
permalink: /articles/2019/10/08/1570532905403.html
---
https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html
