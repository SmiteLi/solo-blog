title: mysql5.7的docker版安装
date: '2019-12-10 16:06:34'
updated: '2019-12-10 16:06:34'
tags: [待分类]
permalink: /articles/2019/12/10/1575965194012.html
---
```
mkdir -p /data/mysql5.7/data
mkdir -p /data/mysql5.7/log
mkdir -p /data/mysql5.7/etc
chown -R 999:999 /data/mysql5.7/

cat << EOF > /data/mysql5.7/etc/my.cnf
[mysqld]
server_id = 100
log-bin = replicas-mysql-bin
binlog_cache_size = 1M
binlog_format = mixed

datadir = /var/lib/mysql
log-error = /var/log/mysql/error.log
secure-file-priv= NULL
port=6094

character-set-client-handshake = FALSE
character-set-server = utf8mb4
collation-server = utf8mb4_unicode_ci
init_connect='SET NAMES utf8mb4'
lower_case_table_names=1
default_authentication_plugin=mysql_native_password

[client]
default-character-set = utf8mb4

[mysql]
default-character-set=utf8mb4
EOF

docker  run -itd \
-e MYSQL_ROOT_PASSWORD=Root@do1.com \
-v /data/mysql5.7/data:/var/lib/mysql \
-v /data/mysql5.7/log:/var/log/mysql \
-v /data/mysql5.7/etc/my.cnf:/etc/mysql/my.cnf \
--name mysql5.7 \
--network host \
--restart=always \
mysql:5.7
```

创建数据库命令：
```
create database mall default character set utf8mb4 collate utf8mb4_unicode_ci;
```

