title: Mongodb backup daily
date: '2019-09-11 15:33:07'
updated: '2019-09-11 15:35:24'
tags: [Linux, shell, mongo]
permalink: /articles/2019/09/11/1568187187538.html
---
1.  write the backup shell script, as follow:
```
#!/bin/bash

MONGODB_BACKUP_DIR="/data/bak/"

cd $MONGODB_BACKUP_DIR

mongodump --host 127.0.0.1 --port 18081 --username admin --password "password@169.com&" --out ./mongodump-`date +%F`

tar -czf mongodump-`date +%F`.tgz ./mongodump-`date +%F`/

rm -rf ./mongodump-`date +%F`/

find . -type f -name '*.tgz' -mtime +30 -print0 | xargs -0 /bin/rm -f

# cd $MONGODB_BACKUP_DIR;tar -xf mongodump-`date +%F`.tgz
# mongorestore --host 127.0.0.1 --port 18081 --username admin --authenticationDatabase=admin /opt/backup/mongodump-2011-10-24
# /bin/bash /data/solution/mongodb3.6/mongo_backup.sh
```

2. set the crontab, every day at 3,am, exec the shell script:
`crontab -e`
```
* 3 * * * /bin/bash /data/mongo_backup.sh
```

