title: ssh配置config文件实现简化登陆
date: '2019-10-22 11:00:40'
updated: '2019-10-22 11:00:40'
tags: [Linux]
permalink: /articles/2019/10/22/1571713240035.html
---
# ssh配置config文件实现简化登陆

背景：需要登陆一台跳板机，然后登陆到众多的服务器去

## 1. 在跳板机配置上配置 .ssh/config
```
Host host1
    Hostname 192.168.0.1
    Port 36000
    User root
    identityFile ~/.ssh/.server_keys/host1-key
Host host2
    Hostname 192.168.0.2
    Port 36000
    User root
    identityFile ~/.ssh/.server_keys/host2-key
```
identityFile 指的是对应服务器的私钥

## 2. 登陆
配置好后，可以用下面的命令登陆host1：
`ssh host1`
