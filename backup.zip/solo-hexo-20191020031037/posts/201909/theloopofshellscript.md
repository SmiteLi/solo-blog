title: the loop of shell script
date: '2019-09-05 17:06:51'
updated: '2019-09-05 17:06:51'
tags: [shell]
permalink: /articles/2019/09/05/1567674411515.html
---
```
#!/bin/bash

  

for count in `seq 0 40`

do

    echo $count

    sleep 1

done

  

date +%F

date +%T

date +'%F %T'

sleep 2

  

for i in {1..6};

do

    set -x

    echo $i

    set +x

done

echo "finisede!"
```
