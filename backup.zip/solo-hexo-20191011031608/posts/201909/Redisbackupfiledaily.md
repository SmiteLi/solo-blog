title: Redis backup file daily
date: '2019-09-12 10:29:08'
updated: '2019-09-12 10:35:40'
tags: [Linux, shell, redis]
permalink: /articles/2019/09/12/1568255347994.html
---
```
#!/bin/bash
# ip: 10.129.1.68
# data dir : /data/solution/redis/data/
# backup dir : /data/redis_bak/

DATA_DIR="/data/solution/redis/data/"
BACKUP_DIR="/data/redis_bak/"

cd /data/solution/redis/
tar -czf redis_bak_`date +%F`.tgz ./data/ >/dev/null 2>&1
mv redis_bak_`date +%F`.tgz $BACKUP_DIR

# keep backup files for 30 days
find $BACKUP_DIR -type f -mtime +30 -name '*.tgz' -print0 | xargs -0 /bin/rm -f

# crontab -e
# * 3 * * * /bin/bash /data/solution/redis/redis_backup.sh
```
