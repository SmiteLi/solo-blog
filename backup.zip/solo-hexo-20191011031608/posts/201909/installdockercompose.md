title: install docker-compose
date: '2019-09-26 16:31:22'
updated: '2019-09-26 16:31:22'
tags: [docker-compose]
permalink: /articles/2019/09/26/1569486682446.html
---
# install docker-compose

## 1. steps
reference:[https://docs.docker.com/compose/install/](https://docs.docker.com/compose/install/)

### 1.1 
`sudo curl -L "https://github.com/docker/compose/releases/download/1.24.1/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose`

### 1.2
`
sudo chmod +x /usr/local/bin/docker-compose
`

## 2 command completion
reference:[https://docs.docker.com/compose/completion/](https://docs.docker.com/compose/completion/)

### 2.1 step
`
 sudo curl -L https://raw.githubusercontent.com/docker/compose/1.24.1/contrib/completion/bash/docker-compose -o /etc/bash_completion.d/docker-compose
`
