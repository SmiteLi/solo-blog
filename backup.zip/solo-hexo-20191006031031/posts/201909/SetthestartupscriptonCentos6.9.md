title: Set the startup script on Centos6.9
date: '2019-09-10 11:57:11'
updated: '2019-09-10 11:57:11'
tags: [Linux, shell]
permalink: /articles/2019/09/10/1568087831690.html
---
```
[root@host-172-16-71-53 ~]# cat /etc/rc.d/rc.local 
#!/bin/sh
#
# This script will be executed *after* all the other init scripts.
# You can put your own initialization stuff in here if you don't
# want to do the full Sys V style init stuff.

touch /var/lock/subsys/local
echo never > /sys/kernel/mm/transparent_hugepage/enabled
echo never > /sys/kernel/mm/transparent_hugepage/defrag
#echo never > /sys/kernel/mm/transparent_hugepage/enabled

bash /data/solution/redis/start.sh
bash /data/solution/redis/start-sentinel.sh

```
把需要执行的脚本放置到rc.local脚本里面即可。
请确保rc.local文件有执行权限
