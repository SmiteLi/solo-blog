title: find命令实例
date: '2019-08-31 08:18:39'
updated: '2019-08-31 08:18:39'
tags: [Linux]
permalink: /articles/2019/08/31/1567210719944.html
---
```
赋予文件执行权限：
find microservice* tifsso* -type f -iname *.sh -o -iname "*-srv" -o -iname "*-api" --o -iname "tifsso*" print0 | xargs -0 chmod +x

find. -name “*.class” -o -name “*.jar”
```
