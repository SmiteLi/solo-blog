title: The shell script of update file
date: '2019-09-09 21:08:12'
updated: '2019-09-09 21:08:12'
tags: [Linux, shell]
permalink: /articles/2019/09/09/1568034492008.html
---
```
cd `dirname $0`
echo "we are in directory $PWD"
sleep 2

NEW_PC_FILE=`ls -lt | grep zip | head -n1 | awk '{print $9}'`
read -p "Is $NEW_PC_FILE the pc files you want to update?(y or n)" CHOOSE

if [ $CHOOSE != "y" ];then
  echo "Note!!! It will not update anything!!!"
  exit 0
fi

echo "Start to backup the files......"
sleep 3
tar -czvf ../page`date "+%F-%T"`.tgz ../page/
echo "finished!!!"
sleep 2

echo "Start to remove the old pc files"
rm -rf favicon.ico index.html static/
echo "finished!!!"
sleep 2

echo "start to update pc files..."
sleep 2
unzip $NEW_PC_FILE
echo "success update!!!"

```
