title: centos7使用chrony进行ntp时间同步
date: '2019-06-12 16:52:26'
updated: '2019-06-12 16:52:26'
tags: [Linux]
permalink: /articles/2019/06/12/1560329546479.html
---
参考：https://blog.51cto.com/12643266/2349098


```
yum install chrony -y
vim /etc/chrony.conf


#4.启动chrony服务，并加入开机自启动

[root@linux-node1 ~]# systemctl start chronyd.service
[root@linux-node1 ~]# systemctl enable chronyd.service

客户端安装了chrony后，可以用下面的命令开启ntp同步：
timedatectl set-ntp 1
```
![image.png](https://img.hacpai.com/file/2019/06/image-a3d1deaf.png)
