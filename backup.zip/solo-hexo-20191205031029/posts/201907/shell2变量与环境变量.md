title: shell-2-变量与环境变量
date: '2019-07-20 13:52:02'
updated: '2019-07-20 13:52:02'
tags: [shell, Linux]
permalink: /articles/2019/07/20/1563601922040.html
---
shell定义了一些变量，用于保存用到的配置信息。查看当前shell中定义的全部环境变量：
```
因为输出较多，我只展示了输出内容的后20行
smite@smite:~$ env | tail -n20
GPG_AGENT_INFO=/run/user/1000/gnupg/S.gpg-agent:0:1
GNOME_TERMINAL_SERVICE=:1.79
XDG_SEAT=seat0
SHLVL=1
LC_TELEPHONE=zh_CN.UTF-8
GDMSESSION=ubuntu
GNOME_DESKTOP_SESSION_ID=this-is-deprecated
LOGNAME=smite
DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus
XDG_RUNTIME_DIR=/run/user/1000
XAUTHORITY=/run/user/1000/gdm/Xauthority
XDG_CONFIG_DIRS=/etc/xdg/xdg-ubuntu:/etc/xdg
PATH=/home/smite/anaconda3/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin
LC_IDENTIFICATION=zh_CN.UTF-8
CONDA_DEFAULT_ENV=base
SESSION_MANAGER=local/smite:@/tmp/.ICE-unix/12432,unix/smite:/tmp/.ICE-unix/12432
LESSOPEN=| /usr/bin/lesspipe %s
GTK_IM_MODULE=fcitx
LC_TIME=zh_CN.UTF-8
_=/usr/bin/env

```
查看其他进程的环境变量：
`cat /proc/$PID/environ ，$PID表示是进程号`
如：查看 12684 进程的环境变量
```
smite@smite:~$ cat /proc/12684/environ | tr '\0' '\n' | head -n10
USER=smite
LC_TIME=zh_CN.UTF-8
TEXTDOMAIN=im-config
XDG_SEAT=seat0
XDG_SESSION_TYPE=x11
SSH_AGENT_PID=12524
SHLVL=0
QT4_IM_MODULE=fcitx
HOME=/home/smite
DESKTOP_SESSION=ubuntu

```
下面学习shell脚本中变量的使用： vim var.sh
```
#!/bin/bash

fruit=apple
count=5
echo "We have $count ${fruit}(s)"

```
运行脚本：
```
smite@smite:~$ bash var.sh 
We have 5 apple(s)

```
从上面的例子可以看出，用 $ 符号就能访问变量的内容了。因为shell使用空白字符分隔单词，所以用{}告诉shell，变量名是fruit，而不是fruit(s)。

export命令声明了将由子进程所继承的一个或者多个变量。这些变量被export后，当前shell脚本所执行的任何应用程序都会获得这个变量。
例如，PATH变量列出了shell搜索特定应用程序的目录，如下：
```
smite@smite:~$ echo $PATH
/home/smite/anaconda3/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin

```
PATH变量通常定义在 /etc/environment,/etc/profile,或者~/.bashrc中。
如果需要添加新的搜索路径，可以用如下命令：
`export PATH=$PATH:/home/user/bin`
执行如下：
```
smite@smite:~$ export PATH=$PATH:/home/user/bin
smite@smite:~$ echo $PATH
/home/smite/anaconda3/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin:/home/user/bin

```
可以看到最后新加了 /home/user/bin 路径。

shell的一些自带特性：
取变量的长度：
```
smite@smite:~$ echo ${#SHELL}
9
smite@smite:~$ echo $SHELL
/bin/bash
smite@smite:~$ echo $0
bash
```

检查用户是否为root：vim check_root.sh
```
#!/bin/bash

if [ $UID -ne 0 ];then
	echo "not root user"
else
	echo root user
fi

```
运行脚本：
```
smite@smite:~$ vim check_root.sh 
smite@smite:~$ bash check_root.sh 
not root user
```





















