title: centos7修复引导
date: '2019-06-11 12:36:41'
updated: '2019-06-11 12:36:41'
tags: [Linux]
permalink: /articles/2019/06/11/1560227801329.html
---
https://blog.csdn.net/xj178926426/article/details/78742449