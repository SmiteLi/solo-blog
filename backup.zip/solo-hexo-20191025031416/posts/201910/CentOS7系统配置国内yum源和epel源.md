title: CentOS7系统配置国内yum源和epel源
date: '2019-10-06 22:22:30'
updated: '2019-10-06 22:22:30'
tags: [centos]
permalink: /articles/2019/10/06/1570371750410.html
---
参考教程：https://www.cnblogs.com/renpingsheng/p/7845096.html
