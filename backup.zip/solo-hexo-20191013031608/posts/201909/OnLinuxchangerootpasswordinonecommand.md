title: On Linux，change root password in one command
date: '2019-09-12 15:28:38'
updated: '2019-09-12 15:28:38'
tags: [OnLinux]
permalink: /articles/2019/09/12/1568273318782.html
---
```
echo "Djy@169.com" | passwd root --stdin
```
