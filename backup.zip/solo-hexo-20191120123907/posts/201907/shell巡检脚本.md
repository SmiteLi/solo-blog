title: shell-巡检脚本
date: '2019-07-19 14:57:11'
updated: '2019-07-19 14:57:22'
tags: [Linux, shell]
permalink: /articles/2019/07/19/1563519431599.html
---
```
#!/usr/bin/env bash
# 检查服务器的 cpu， 内存， 硬盘， 各个服务

#可以使用一下命令查使用内存最多的10个进程
#ps -aux | sort -k4nr | head -n 10


#可以使用一下命令查使用CPU最多的10个进程
#ps -aux | sort -k3nr | head -n 10

cd `dirname $0`

REPORTDIR=reports
REPORTFILE=`date +%F`.report

echo > ${REPORTDIR}/${REPORTFILE}

echo -e "\n巡检开始\n"
echo -e "\n巡检开始\n" >> ${REPORTDIR}/${REPORTFILE}

echo -e "\n============================\n" >> ${REPORTDIR}/${REPORTFILE}
echo "Cpu 负载情况：" >> ${REPORTDIR}/${REPORTFILE}
ansible -i ./hosts all -m shell -a "ps -aux | sort -k3nr | head -n 15" >> ${REPORTDIR}/${REPORTFILE}

echo -e "\n============================\n"  >> ${REPORTDIR}/${REPORTFILE}
echo "内存使用情况："  >> ${REPORTDIR}/${REPORTFILE}
ansible -i ./hosts all -m shell -a "free -h" >> ${REPORTDIR}/${REPORTFILE}

echo -e "\n============================\n" >> ${REPORTDIR}/${REPORTFILE}
echo "硬盘使用情况：" >> ${REPORTDIR}/${REPORTFILE}
ansible -i ./hosts all -m shell -a "df -hT" >> ${REPORTDIR}/${REPORTFILE}

echo -e "\n============================\n" >> ${REPORTDIR}/${REPORTFILE}
echo -e "监听端口：\n" >> ${REPORTDIR}/${REPORTFILE}
ansible -i ./hosts all -m shell -a "netstat -lntp" >> ${REPORTDIR}/${REPORTFILE}

echo -e "\n============================\n" >> ${REPORTDIR}/${REPORTFILE}
echo "检查elk服务：" >> ${REPORTDIR}/${REPORTFILE}
ansible -i ./hosts elk -m shell -a "ps -aux | grep elasticsearch" >> ${REPORTDIR}/${REPORTFILE}

echo -e "\n============================\n" >> ${REPORTDIR}/${REPORTFILE}
echo "检查kibana服务：" >> ${REPORTDIR}/${REPORTFILE}
ansible -i ./hosts 173.26.11.18 -m shell -a "ps -aux | egrep kibana" >> ${REPORTDIR}/${REPORTFILE}

echo -e "\n============================\n" >> ${REPORTDIR}/${REPORTFILE}
echo "检查数据库服务：" >> ${REPORTDIR}/${REPORTFILE}
ansible -i ./hosts db_server -m shell -a "docker ps -a" >> ${REPORTDIR}/${REPORTFILE}

echo -e "\n巡检结束\n" >> ${REPORTDIR}/${REPORTFILE}
echo -e "\n巡检结束\n"
```