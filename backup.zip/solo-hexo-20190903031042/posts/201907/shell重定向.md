title: shell-重定向
date: '2019-07-20 17:54:53'
updated: '2019-07-20 17:56:50'
tags: [shell, Linux]
permalink: /articles/2019/07/20/1563616493883.html
---
![](https://img.hacpai.com/bing/20180316.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

文件描述符是与某个打开的文件或数据流相关联的整数。文件描述符0,1,2是系统预留的。
* 0 ，即stdin，标准输入，即从键盘输入
* 1，即stdout，标准输出，输出到屏幕
* 2，即stderr，标准错误输出，把错误信息输出到屏幕
编写脚本：vim std.sh
```
#!/bin/bash

echo "hello world" > /tmp/temp.txt
echo "hello world" >> /tmp/temp.txt

cat /tmp/temp.txt

ls + > /tmp/err.txt
cat /tmp/err.txt
echo "hello world" > /tmp/temp.txt

ls ~ + > /tmp/err.txt 2>&1


cat /tmp/err.txt

ls ~ + &> /tmp/err.txt 
cat /tmp/err.txt
cat <<EOF >/tmp/log.txt
this is the log file.
EOF
cat /tmp/log.txt

# 配置命令的别名
alias
alias rm='cp $@ ~/backup && rm $@'

```