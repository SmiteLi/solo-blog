title: Linux服务器上线前参数调整
date: '2019-08-31 20:28:20'
updated: '2019-08-31 20:28:20'
tags: [Linux]
permalink: /articles/2019/08/31/1567254500496.html
---
```
  

redis.conf 增加这个配置 tcp-backlog 2048

  

vim /etc/sysctl.conf

net.core.somaxconn=2048

vm.overcommit_memory=1

Linux环境检查与配置

- cat /proc/sys/fs/file-max: 应设置在10032以上

  

- 否则在文件/etc/sysctl.conf中配置: fs.file-max = 10032

- 执行sysctl -p生效

  

- cat /proc/sys/net/core/somaxconn: 应显示为2048以上

  

- 否则在文件/etc/sysctl.conf中配置: net.core.somaxconn=2048

- 执行sysctl -p生效

  

- cat /etc/sysctl.conf: 应包含vm.overcommit_memory=1

  

- 否则在文件/etc/sysctl.conf中配置: vm.overcommit_memory = 1

- 执行sysctl -p生效

  

- cat /sys/kernel/mm/transparent_hugepage/enabled

  

- 部分版本显示[always] madvise never:

  

echo never > /sys/kernel/mm/transparent_hugepage/enabled

  

则将以下两行命令加入/etc/rc.d/rc.local

vim /etc/rc.d/rc.local

echo never > /sys/kernel/mm/transparent_hugepage/enabled

echo never > /sys/kernel/mm/transparent_hugepage/defrag

  

将以下一行命令加入/etc/rc.local

echo never > /sys/kernel/mm/transparent_hugepage/enabled

  

- 部分版本显示No such file or directory: 则忽略该设置
```
