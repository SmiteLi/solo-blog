title: ansible使用实例
date: '2019-10-06 14:50:13'
updated: '2019-10-06 14:50:13'
tags: [ansible]
permalink: /articles/2019/10/06/1570344613660.html
---
```
ssh-keygen -t rsa
ssh-copy-id   root@47.106.93.184  // public.key 复制到client去

ssh-agent是一个密钥管理器，运行ssh-agent以后，使用ssh-add将私钥交给ssh-agent保管，其他程序需要身份验证的时候可以将验证申请交给ssh-agent来完成整个认证过程。
$ ssh-agent bash
$ ssh-add ~/.ssh/id_rsa

$ ansible all -m ping
# as bruce
$ ansible all -m ping -u bruce
# as bruce, sudoing to root
$ ansible all -m ping -u bruce --sudo
# as bruce, sudoing to batman
$ ansible all -m ping -u bruce --sudo --sudo-user batman

# With latest version of ansible `sudo` is deprecated so use become
# as bruce, sudoing to root
$ ansible all -m ping -u bruce -b
# as bruce, sudoing to batman
$ ansible all -m ping -u bruce -b --become-user batman

$ ansible all -a "/bin/echo hello"

$ ansible localhost -m ping -e 'ansible_python_interpreter="/usr/bin/env python"'

https://docs.ansible.com/ansible/latest/cli/ansible.html
ansible <host-pattern> [options]

REPL(Read-eval-print-loop)：交互式解析器

$ ansible atlanta -a "/sbin/reboot" -f 10
$ ansible atlanta -a "/usr/bin/foo" -u username
$ ansible atlanta -a "/usr/bin/foo" -u username --become [--ask-become-pass]
$ ansible atlanta -a "/usr/bin/foo" -u username --become --become-user otheruser [--ask-become-pass]
$ ansible all -m shell -a 'echo $TERM'

$ ansible all -m copy -a "src=/etc/hosts dest=/tmp/hosts"
$ ansible webservers -m file -a "dest=/srv/foo/a.txt mode=600"
$ ansible webservers -m file -a "dest=/srv/foo/b.txt mode=600 owner=mdehaan group=mdehaan"
similar to mkdir -p:
$ ansible webservers -m file -a "dest=/path/to/c mode=755 owner=mdehaan group=mdehaan state=directory"
delete directories (recursively) and delete files:
$ ansible webservers -m file -a "dest=/path/to/c state=absent"

https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html
$ ansible webservers -m yum -a "name=acme state=present"
$ ansible webservers -m yum -a "name=acme-1.5 state=present"
$ ansible webservers -m yum -a "name=acme state=latest"
$ ansible webservers -m yum -a "name=acme state=absent"
ansible all -m apt -a "name=mysql-server state=present"

$ ansible webservers -m git -a "repo=https://foo.example.org/repo.git dest=/srv/myapp version=HEAD"

$ ansible all -m user -a "name=foo password=<crypted password here>"
$ ansible all -m user -a "name=foo state=absent"

$ ansible all -m service -a "name=mysql state=started"
$ ansible webservers -m service -a "name=httpd state=restarted"
$ ansible webservers -m service -a "name=httpd state=stopped"

$ ansible all -m setup

后台运行：
$ ansible all -B 3600 -P 0 -a "/usr/bin/long_running_operation --do-stuff"
$ ansible web1.example.com -m async_status -a "jid=488359678239.2844"

$ ansible all -B 1800 -P 60 -a "/usr/bin/long_running_operation --do-stuff"
The above example says “run for 30 minutes max (-B 30*60=1800), poll for status (-P) every 60 seconds”.
```
