title: ansible命令介绍
date: '2019-09-02 15:15:16'
updated: '2019-09-02 15:15:16'
tags: [ansible, Linux]
permalink: /articles/2019/09/02/1567408516348.html
---
1. ansible 

ansible \<host-pattern\> [options]

ansible 是一个非常简单的工具/框架/ API，用于做“远程事物”。此命令允许您针对一组主机定义和运行单个任务“playbook”

2. 常用选项
--ask-vault-pass
要求保管库密码

--become-method <BECOME_METHOD>
要使用的权限提升方法（默认=％默认值），请使用ansible-doc -t成为-l列出有效选项。

--become-user <BECOME_USER>
以此用户身份运行操作（默认= root）

--list-hosts
输出匹配主机列表; 不会执行任何其他操作

--playbook-dir <BASEDIR>
由于此工具不使用playbooks，因此将其用作替代playbook目录。这为许多功能设置了相对路径，包括roles / group_vars / etc.

--private-key, --key-file
使用此文件来验证连接

--scp-extra-args <SCP_EXTRA_ARGS>
指定仅传递给scp的额外参数（例如-l）

--sftp-extra-args <SFTP_EXTRA_ARGS>
指定仅传递给sftp的额外参数（例如-f，-l）

--ssh-common-args <SSH_COMMON_ARGS>
指定传递给sftp / scp / ssh的公共参数（例如ProxyCommand）

--ssh-extra-args <SSH_EXTRA_ARGS>
指定仅传递给ssh的额外参数（例如-R）

--syntax-check
对playbook执行语法检查，但不执行它

--vault-id
要使用的保管库标识

--vault-password-file
保管库密码文件

--version
显示程序的版本号，配置文件位置，配置的模块搜索路径，模块位置，可执行文件位置和退出

-B <SECONDS>, --background <SECONDS>
异步运行，X秒后失败（默认= N / A）

-C, --check
不做任何改变; 相反，尝试预测可能发生的一些变化

-D, --diff
更改（小）文件和模板时，显示这些文件的差异; 与-check一起使用效果很好

-K, --ask-become-pass
要求提供权限提升密码

-M, --module-path
将冒号分隔的路径预先添加到模块库（默认=〜/ .ansible / plugins / modules：/ usr / share / ansible / plugins / modules）

-P <POLL_INTERVAL>, --poll <POLL_INTERVAL>
如果使用-B（默认值= 15），则设置轮询间隔

-T <TIMEOUT>, --timeout <TIMEOUT>
以秒为单位覆盖连接超时（默认值= 10）

-a <MODULE_ARGS>, --args <MODULE_ARGS>
模块参数

-b, --become
用run运行操作（不暗示密码提示）

-c <CONNECTION>, --connection <CONNECTION>
要使用的连接类型（默认=智能）

-e, --extra-vars
将其他变量设置为key = value或YAML / JSON，如果filename前缀为@

-f <FORKS>, --forks <FORKS>
指定要使用的并行进程数（默认值= 5）

-h, --help
显示此帮助消息并退出

-i, --inventory, --inventory-file
指定库存主机路径或逗号分隔的主机列表。-inventory-file已弃用

-k, --ask-pass
询问连接密码

-l <SUBSET>, --limit <SUBSET>
进一步将所选主机限制为其他模式

-m <MODULE_NAME>, --module-name <MODULE_NAME>
要执行的模块名称（default = command）

-o, --one-line
浓缩输出

-t <TREE>, --tree <TREE>
将输出记录到此目录

-u <REMOTE_USER>, --user <REMOTE_USER>
以此用户身份连接（默认=无）

-v, --verbose
详细模式（-vvv表示更多，-vvvv表示启用连接调试）

3. 环境
可以指定以下环境变量。

ANSIBLE_CONFIG - 覆盖默认的ansible配置文件

在ansible.cfg中，大多数选项都有更多可用的选项

4. 文件
/etc/ansible/ansible.cfg - 配置文件，如果存在则使用

~/.ansible.cfg - 用户配置文件，覆盖默认配置（如果存在）

