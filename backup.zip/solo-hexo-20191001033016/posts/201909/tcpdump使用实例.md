title: tcpdump使用实例
date: '2019-09-20 18:40:53'
updated: '2019-09-20 18:40:53'
tags: [Linux]
permalink: /articles/2019/09/20/1568976053479.html
---
```
tcpdump -i eth0 host 172.16.13.88 and port 80  -w wg72.cap
tcpdump -i eth0 host 19.15.6.9 or host 19.15.6.10 and port 8080 -w yw101.cap
```
