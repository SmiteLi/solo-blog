title: lvm卷的使用
date: '2019-07-22 20:33:04'
updated: '2019-10-10 11:56:04'
tags: [Linux, shell]
permalink: /articles/2019/07/22/1563798784406.html
---
## 一、lvm常用操作
```
fdisk -l
lsblk
pvcreate /dev/xvde
pvcreate /dev/xvdf
pvcreate /dev/xvdg
vgcreate lvmdisk /dev/xvde
vgextend lvmdisk /dev/xvdf
vgextend lvmdisk /dev/xvdg
lvcreate -l +100%FREE -n data lvmdisk
mkfs -t ext4 /dev/mapper/lvmdisk-data
mkdir /data
mount /dev/mapper/lvmdisk-data /data
echo "/dev/mapper/lvmdisk-data /data ext4 defaults 1 2">>/etc/fstab
cat /etc/fstab
df -hT	

把vg = /dev/mapper/cl-root 百分百扩展
lvextend -l +100%Free /dev/mapper/cl-root
文件系统扩展：
resize2fs /dev/mapper/cl-root
在centos7.6上报错：
resize2fs: Bad magic number in super-block while trying to open /dev/mapper/cl-root
Couldn't find valid filesystem superblock.
原来centos7之后用的是xfs文件系统，所以应该用以下命令：
xfs_growfs /dev/mapper/cl-root
用 df -hT 可以看到已经成功扩容

```

## 二、centos7进行lvm扩展。
```
背景： 已经有一个lvm卷 /dev/centos/root，新加了一个硬盘 /dev/sdb

创建pv：
pvcreate /dev/sdb
pvdisplay
vgdisplay
扩展vg ： centos
vgextend centos /dev/sdb
vgdisplay 
扩展lv：/dev/centos/root：
lvdisplay 
lvextend -l +100%FREE /dev/centos/root
lvdisplay 
扩展文件系统：
xfs_growfs /dev/centos/root
```
