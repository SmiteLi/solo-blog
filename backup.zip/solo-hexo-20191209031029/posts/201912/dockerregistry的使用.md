title: docker registry的使用
date: '2019-12-06 10:53:49'
updated: '2019-12-06 11:22:49'
tags: [docker]
permalink: /articles/2019/12/06/1575600829014.html
---
## 参考资料：
[资料](https://docs.docker.com/registry/deploying/)

## 最佳实践
1. Create a password file with one entry for the user `testuser`, with password `testpassword`:
    
    ```
    $ mkdir auth
    $ docker run \
      --entrypoint htpasswd \
      registry:2 -Bbn testuser testpassword > auth/htpasswd
    
    ```
    
2. Stop the registry.
    
    ```
    $ docker container stop registry
    
    ```
    
3. Start the registry with basic authentication.
    
    ```
    $ docker run -d \
      -p 5000:5000 \
      --restart=always \
      --name registry \
      -v "$(pwd)"/auth:/auth \
      -e "REGISTRY_AUTH=htpasswd" \
      -e "REGISTRY_AUTH_HTPASSWD_REALM=Registry Realm" \
      -e REGISTRY_AUTH_HTPASSWD_PATH=/auth/htpasswd \
      -v "$(pwd)"/certs:/certs \
      -e REGISTRY_HTTP_TLS_CERTIFICATE=/certs/domain.crt \
      -e REGISTRY_HTTP_TLS_KEY=/certs/domain.key \
      registry:2
    
    ```
    
4. Try to pull an image from the registry, or push an image to the registry. These commands fail.
    
5. Log in to the registry.
    
    ```
    $ docker login myregistrydomain.com:5000
    
    ```
    
    Provide the username and password from the first step.
    
    Test that you can now pull an image from the registry or push an image to the registry.

## 登录
`docker login -u 用户名 -p 密码`

`docker logout`

## 推送和拉取
Tag the image so that it points to your registry

```
docker image tag ubuntu localhost:5000/myfirstimage

```

Push it

```
docker push localhost:5000/myfirstimage

```

Pull it back

```
docker pull localhost:5000/myfirstimage
```
