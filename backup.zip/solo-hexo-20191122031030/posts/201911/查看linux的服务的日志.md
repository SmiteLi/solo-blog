title: 查看linux的服务的日志
date: '2019-11-20 11:15:37'
updated: '2019-11-20 11:15:37'
tags: [Linux]
permalink: /articles/2019/11/20/1574219737259.html
---
```
systemctl stop rio-apigate;systemctl start rio-apigate;journalctl -u rio-apigate -f
```
![image.png](https://img.hacpai.com/file/2019/11/image-76dfcece.png)

