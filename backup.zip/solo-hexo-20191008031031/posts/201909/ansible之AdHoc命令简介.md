title: ansible之Ad-Hoc命令简介
date: '2019-09-02 15:21:37'
updated: '2019-09-02 15:21:37'
tags: [ansible]
permalink: /articles/2019/09/02/1567408897272.html
---
# [Ad-Hoc命令简介](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#id7)[](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#introduction-to-ad-hoc-commands "永久链接到这个标题")

话题

* [Ad-Hoc命令简介](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#introduction-to-ad-hoc-commands)
    * [并行和Shell命令](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#parallelism-and-shell-commands)
    * [文件传输](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#file-transfer)
    * [管理包](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#managing-packages)
    * [用户和组](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#users-and-groups)
    * [从源代码管理部署](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#deploying-from-source-control)
    * [管理服务](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#managing-services)
    * [时间有限的背景操作](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#time-limited-background-operations)
    * [收集事实](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#gathering-facts)

以下示例显示如何使用/ usr / bin / ansible运行即席任务。

什么是ad-hoc命令？

ad-hoc命令是您可以键入的内容，可以非常快速地执行某些操作，但不希望以后再保存。

这是一个开始理解Ansible在学习playbooks语言之前可以做的基础知识的好地方 - ad-hoc命令也可以用来做快速的事情，你可能不一定想写一个完整的剧本。

一般来说，Ansible的真正力量在于剧本。为什么你会使用临时任务而不是剧本？

例如，如果您想在圣诞假期关闭所有实验室电源，您可以在Ansible中执行快速单行程，而无需编写剧本。

但是，对于配置管理和部署，您需要使用'/ usr / bin / ansible-playbook' - 您将在此处学习的概念将直接移植到playbook语言。

（有关这些内容的更多信息，请参阅[使用Playbooks](https://docs.ansible.com/ansible/latest/user_guide/playbooks.html)）

如果您还没有阅读[使用库存](https://docs.ansible.com/ansible/latest/user_guide/intro_inventory.html)，请先查看一下，然后我们就会开始。

## [并行和Shell命令](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#id8)[](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#parallelism-and-shell-commands "永久链接到这个标题")

任意的例子。

让我们使用Ansible的命令行工具重启亚特兰大的所有Web服务器，一次10个。首先，让我们设置SSH代理，以便它能记住我们的凭据：

$ ssh-agent bash
$ ssh-add ~/.ssh/id_rsa

如果您不想使用ssh-agent并希望使用密码而不是密钥进行SSH，则可以使用`--ask-pass`（`-k`），但最好只使用ssh-agent。

现在在组中的所有服务器上运行该命令，在本例中为 *atlanta*，以10个并行分叉运行：

$ ansible atlanta -a "/sbin/reboot" -f 10

/ usr / bin / ansible将默认从您的用户帐户运行。如果您不喜欢此行为，请传入“-u username”。如果要以不同的用户身份运行命令，它看起来像这样：

$ ansible atlanta -a "/usr/bin/foo" -u username

通常，您不希望仅从您的用户帐户执行操作。如果要通过权限提升运行命令：

$ ansible atlanta -a "/usr/bin/foo" -u username --become [--ask-become-pass]

如果您没有使用无密码权限提升方法（sudo / su / pfexec / doas / etc），请使用`--ask-become-pass`（`-K`）。这将以交互方式提示您输入密码。使用无密码设置可以使事情更容易自动化，但这不是必需的。

使用以下内容也可以成为root之外的用户 `--become-user`：

$ ansible atlanta -a "/usr/bin/foo" -u username --become --become-user otheruser [--ask-become-pass]

注意

很少有一些用户拥有安全规则，他们将sudo / pbrun / doas环境限制为仅运行特定的命令路径。这不适用于Ansible的无引导理念和数百个不同的模块。如果这样做，请从没有此约束的特殊帐户使用Ansible。在没有共享访问未授权用户的情况下执行此操作的一种方法是使用[Red Hat Ansible Tower](https://docs.ansible.com/ansible/latest/reference_appendices/tower.html#ansible-tower)控制Ansible ，它可以保留SSH凭据，并允许某些组织的成员代表他们使用它而无需直接访问。

好的，所以这些都是基础知识。如果您还没有阅读有关模式和组的信息，请返回并阅读[使用模式](https://docs.ansible.com/ansible/latest/user_guide/intro_patterns.html#intro-patterns)。

的上述指定10个同时处理的用法来使用。您也可以在[配置Ansible中](https://docs.ansible.com/ansible/latest/installation_guide/intro_configuration.html#intro-configuration)进行设置，以避免再次进行设置。默认值实际上是5，这非常小而且保守。你可能想要与更多的同步主机进行交流，所以请随意提出这个问题。如果您拥有的主机数多于为fork计数设置的值，Ansible将与他们交谈，但需要更长的时间。随意将此值推到系统可以处理的最高值！`-f 10`[](https://docs.ansible.com/ansible/latest/installation_guide/intro_configuration.html#intro-configuration)

您还可以选择要运行的Ansible“模块”。通常命令也采用`-m`for模块名称，但默认模块名称为'command'，因此我们不需要一直指定。我们将`-m`在后面的示例中使用其他一些[使用模块](https://docs.ansible.com/ansible/latest/user_guide/modules.html)。

注意

该[命令模块](https://docs.ansible.com/ansible/latest/modules/command_module.html#command-module)不支持这样的管道和重定向扩展shell语法（尽管shell变量会一直工作）。如果您的命令需要特定于shell的语法，请改用shell模块。阅读有关“ [使用模块”](https://docs.ansible.com/ansible/latest/user_guide/modules.html#working-with-modules)页面上的差异的更多信息 。

使用[shell模块](https://docs.ansible.com/ansible/latest/modules/shell_module.html#shell-module)如下所示：

$ ansible raleigh -m shell -a 'echo $TERM'

使用Ansible *ad hoc* CLI（而不是 [Playbooks](https://docs.ansible.com/ansible/latest/user_guide/playbooks.html)）运行任何命令时，请特别注意shell引用规则，因此本地shell在传递给Ansible之前不会使用变量。例如，在上面的示例中使用双引号而不是单引号将评估您所在框中的变量。

到目前为止，我们一直在演示简单的命令执行，但大多数Ansible模块不是简单的命令式脚本。相反，他们使用声明性模型，计算并执行达到指定最终状态所需的操作。此外，它们通过在开始之前检查当前状态来实现一种幂等形式，并且如果当前状态与指定的最终状态匹配，则什么都不做。但是，我们也认识到运行任意命令可能很有价值，因此Ansible很容易支持这两种命令。

## [文件传输](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#id9)[](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#file-transfer "永久链接到这个标题")

这是/ usr / bin / ansible命令行的另一个用例。Ansible可以将大量文件并行地存储到多台机器上。

要将文件直接传输到许多服务器：

$ ansible atlanta -m copy -a "src=/etc/hosts dest=/tmp/hosts"

如果您使用playbooks，您还可以利用该`template`模块，这将进一步迈出这一步。（参见模块和剧本文档）。

该`file`模块允许更改文件的所有权和权限。这些相同的选项也可以直接传递给`copy`模块：

$ ansible webservers -m file -a "dest=/srv/foo/a.txt mode=600"
$ ansible webservers -m file -a "dest=/srv/foo/b.txt mode=600 owner=mdehaan group=mdehaan"

该`file`模块还可以创建目录，类似于：`mkdir -p`

$ ansible webservers -m file -a "dest=/path/to/c mode=755 owner=mdehaan group=mdehaan state=directory"

以及删除目录（递归）和删除文件：

$ ansible webservers -m file -a "dest=/path/to/c state=absent"

## [管理包](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#id10)[](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#managing-packages "永久链接到这个标题")

有适用于yum和apt的模块。以下是yum的一些例子。

确保已安装软件包，但不要更新它：

$ ansible webservers -m yum -a "name=acme state=present"

确保将软件包安装到特定版本：

$ ansible webservers -m yum -a "name=acme-1.5 state=present"

确保包装是最新版本：

$ ansible webservers -m yum -a "name=acme state=latest"

确保未安装包：

$ ansible webservers -m yum -a "name=acme state=absent"

Ansible具有用于在许多平台下管理包的模块。如果您的软件包管理器没有模块，您可以使用命令模块安装软件包，或者（更好！）为软件包管理器提供一个模块。请在邮件列表中查看信息/详细信息。

## [用户和组](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#id11)[](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#users-and-groups "永久链接到这个标题")

“用户”模块允许轻松创建和操作现有用户帐户，以及删除可能存在的用户帐户：

$ ansible all -m user -a "name=foo password=<crypted password here>"

$ ansible all -m user -a "name=foo state=absent"

有关所有可用选项的详细信息，请参阅“ [使用模块”](https://docs.ansible.com/ansible/latest/user_guide/modules.html)部分，包括如何操作组和组成员身份。

## [从源代码控制部署](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#id12)[](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#deploying-from-source-control "永久链接到这个标题")

直接从git部署webapp：

$ ansible webservers -m git -a "repo=https://foo.example.org/repo.git dest=/srv/myapp version=HEAD"

由于Ansible模块可以通知更改处理程序，因此可以告诉Ansible在更新代码时运行特定任务，例如直接从git部署Perl / Python / PHP / Ruby，然后重新启动apache。

## [管理服务](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#id13)[](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#managing-services "永久链接到这个标题")

确保在所有Web服务器上启动服务：

$ ansible webservers -m service -a "name=httpd state=started"

或者，在所有Web服务器上重新启动服务：

$ ansible webservers -m service -a "name=httpd state=restarted"

确保服务已停止：

$ ansible webservers -m service -a "name=httpd state=stopped"

## [时间有限的后台操作](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#id14)[](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#time-limited-background-operations "永久链接到这个标题")

长时间运行的操作可以在后台运行，以后可以检查它们的状态。例如，要`long_running_operation` 在后台异步执行，超时为3600秒（`-B`），并且没有轮询（`-P`）：

$ ansible all -B 3600 -P 0 -a "/usr/bin/long_running_operation --do-stuff"

如果您确定稍后要检查作业状态，则可以使用async_status模块，并在后台运行原始作业时返回的作业ID：

$ ansible web1.example.com -m async_status -a "jid=488359678239.2844"

轮询是内置的，看起来像这样：

$ ansible all -B 1800 -P 60 -a "/usr/bin/long_running_operation --do-stuff"

上面的例子说“最多运行30分钟（`-B`30 * 60 = 1800），`-P`每60秒轮询状态（）”。

轮询模式很智能，因此在任何机器上开始轮询之前，所有作业都将启动。`--forks`如果您希望快速启动所有工作，请务必使用足够高的值。在时间限制（以秒为单位）用完（`-B`）后，远程节点上的进程将终止。

通常，您只需要运行长时间运行的shell命令或软件升级。后台复制模块不执行后台文件传输。 [Playbooks](https://docs.ansible.com/ansible/latest/user_guide/playbooks.html)还支持轮询，并为此提供简化的语法。

## [收集事实](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#id15)[](https://docs.ansible.com/ansible/latest/user_guide/intro_adhoc.html#gathering-facts "永久链接到这个标题")

事实在playbooks部分中描述，并代表有关系统的已发现变量。这些可用于实现任务的条件执行，但也可用于获取有关系统的临时信息。你可以看到所有事实：

$ ansible all -m setup

也可以过滤此输出以仅导出某些事实，有关详细信息，请参阅“设置”模块文档。
